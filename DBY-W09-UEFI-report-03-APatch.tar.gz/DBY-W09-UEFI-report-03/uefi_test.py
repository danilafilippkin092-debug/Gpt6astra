#!/usr/bin/env python3
"""DBY-W09 interactive experimental UEFI test. prepare/report read boot; start explicitly writes boot."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import stat
import struct
import subprocess
import sys
import tarfile
import tempfile
import time
import zlib

KIT = Path(__file__).resolve().parent
SHARED = Path('/data/media/0/DBY-UEFI-REPORT-03')
STATE = KIT / '.private-test-state.json'
SIZE = 100663296
UEFI_NAME = 'DBY-W09-UEFI-report-03.img'
UEFI_SHA = '221e86637b1cf1552329490ac1678797c0c7f28bf1a5184e8ffb41b306826444'
PADDED_SHA = '0110095fefc98a6c6dec8220733e963b35b071dd2cfbd8d385fc0313336ca76d'


def digest_file(path):
    h = hashlib.sha256()
    with open(path, 'rb', buffering=0) as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def copy_all_writes(source, destination):
    while True:
        chunk = source.read(1024 * 1024)
        if not chunk:
            return
        view = memoryview(chunk)
        while view:
            written = destination.write(view)
            if written is None or written <= 0:
                raise OSError('Short boot write made no progress')
            view = view[written:]


def verify_file(path, expected, size=None):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f'Not a regular, non-symlink file: {path}')
    if size is not None and path.stat().st_size != size:
        raise RuntimeError(f'Wrong file size: {path}')
    if digest_file(path) != expected:
        raise RuntimeError(f'SHA256 mismatch: {path}')


def atomic_json(path, value):
    path = Path(path)
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def prop(name):
    return subprocess.check_output(['/system/bin/getprop', name], text=True).strip()


def check_android_device():
    values = {k: prop(k) for k in (
        'ro.product.model', 'ro.product.device', 'ro.board.platform',
        'ro.boot.flash.locked', 'ro.boot.slot_suffix', 'ro.boot.verifiedbootstate')}
    if values['ro.product.model'] not in ('DBY-W09', 'DBY-W09S'):
        raise RuntimeError('Only DBY-W09/DBY-W09S is accepted')
    if values['ro.product.device'] != 'HWDBY' or values['ro.board.platform'] != 'kona':
        raise RuntimeError('HWDBY/Kona identity mismatch')
    if values['ro.boot.flash.locked'] != '0' or values['ro.boot.slot_suffix']:
        raise RuntimeError('Unlocked, non-A/B boot layout is required')
    return values


def resolve_partition(name):
    if name not in ('boot', 'recovery', 'recovery_ramdisk'):
        raise RuntimeError('Unexpected partition name')
    candidates = set()
    for directory in ('/dev/block/by-name', '/dev/block/bootdevice/by-name'):
        path = Path(directory) / name
        if path.exists():
            candidates.add(path.resolve(strict=True))
    if len(candidates) != 1:
        raise RuntimeError('Missing or ambiguous ' + name + ' partition')
    path = candidates.pop()
    if not stat.S_ISBLK(path.stat().st_mode):
        raise RuntimeError('Partition is not a block device: ' + name)
    with path.open('rb', buffering=0) as stream:
        size = struct.unpack('=Q', fcntl.ioctl(stream.fileno(), 0x80081272, bytes(8)))[0]
    return path, size


def recovery_header_check(header, partition_size):
    if len(header) < 44 or header[:8] != b'ANDROID!':
        raise RuntimeError('Recovery does not have a recognized independent kernel header')
    kernel_size = struct.unpack_from('<I', header, 8)[0]
    page = struct.unpack_from('<I', header, 36)[0]
    version = struct.unpack_from('<I', header, 40)[0]
    if not (2048 <= page <= 65536 and page & (page - 1) == 0 and version <= 2):
        raise RuntimeError('Unrecognized recovery image layout')
    if not (0 < kernel_size <= partition_size - page):
        raise RuntimeError('Recovery lacks its own kernel; a host is needed for rollback')
    return dict(kernel_bytes=kernel_size, page_size=page, header_version=version)


def check_recovery_independence(boot_path):
    recovery, size = resolve_partition('recovery')
    ramdisk, _ = resolve_partition('recovery_ramdisk')
    if recovery == boot_path or ramdisk == boot_path or ramdisk == recovery:
        raise RuntimeError('Recovery aliases boot; refusing this host-free test')
    with recovery.open('rb', buffering=0) as stream:
        header = stream.read(4096)
        result = recovery_header_check(header, size)
        stream.seek(result['page_size'])
        prefix = stream.read(64)
    if not (prefix.startswith(b'\x1f\x8b') or prefix[56:60] == b'ARM\x64'):
        raise RuntimeError('Recovery kernel format is not recognized')
    result.update(recovery_sha256=digest_file(recovery), recovery_ramdisk_sha256=digest_file(ramdisk))
    return result


class BootDevice:
    def __init__(self):
        candidates = set()
        for path in ('/dev/block/by-name/boot', '/dev/block/bootdevice/by-name/boot'):
            p = Path(path)
            if p.exists():
                candidates.add(p.resolve(strict=True))
        if len(candidates) != 1:
            raise RuntimeError('Missing or ambiguous boot partition; no writes')
        self.path = candidates.pop()
        if not stat.S_ISBLK(self.path.stat().st_mode):
            raise RuntimeError('boot target is not a block device')
        with self.path.open('rb', buffering=0) as stream:
            size = struct.unpack('=Q', fcntl.ioctl(stream.fileno(), 0x80081272, bytes(8)))[0]
        if size != SIZE:
            raise RuntimeError(f'Unexpected boot partition size: {size}')

    def digest(self):
        return digest_file(self.path)

    def copy_to(self, destination):
        with self.path.open('rb', buffering=0) as src, Path(destination).open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())

    def write(self, image):
        # Only this previously verified boot block device is ever opened for writing.
        with Path(image).open('rb') as src, self.path.open('wb', buffering=0) as dst:
            copy_all_writes(src, dst)
            os.fsync(dst.fileno())


def boot_identity(path):
    with Path(path).open('rb') as stream:
        header = stream.read(4096)
        if len(header) != 4096 or header[:8] != b'ANDROID!':
            raise RuntimeError('Expected Android boot header')
        values = struct.unpack_from('<10I', header, 8)
        kernel_size, kernel_addr, ramdisk_size, ramdisk_addr, second_size, _, tags, page, version, _ = values
        if not (0 < kernel_size <= 64 * 1024 * 1024) or second_size:
            raise RuntimeError('Expected a kernel-bearing boot image without a second stage')
        if page != 4096 or version != 2:
            raise RuntimeError('Only the audited boot v2 / 4096-byte page layout is accepted')
        dtb_size = struct.unpack_from('<I', header, 1648)[0]
        dtb_addr = struct.unpack_from('<Q', header, 1652)[0]
        recovery_size = struct.unpack_from('<I', header, 1632)[0]
        if recovery_size:
            raise RuntimeError('Unexpected recovery DTBO in boot image')
        align = lambda n: (n + page - 1) // page * page
        offset = page + align(kernel_size) + align(ramdisk_size) + align(second_size)
        if not 40 <= dtb_size <= 4 * 1024 * 1024 or offset + dtb_size > Path(path).stat().st_size:
            raise RuntimeError('Invalid DTB bounds')
        stream.seek(offset)
        dtb = stream.read(dtb_size)
        if len(dtb) != dtb_size:
            raise RuntimeError('Short DTB read')
        return dict(kernel_addr=kernel_addr, ramdisk_addr=ramdisk_addr, tags_addr=tags,
                    dtb_addr=dtb_addr, dtb_sha256=hashlib.sha256(dtb).hexdigest())


def assert_android_backup(path):
    # Reject a previous raw BootShim/UEFI boot before accepting it as Android.
    boot_identity(path)
    with Path(path).open('rb') as stream:
        header = stream.read(4096)
        kernel_size = struct.unpack_from('<I', header, 8)[0]
        stream.seek(4096)
        compressed = stream.read(min(kernel_size, 1024 * 1024))
    if not compressed.startswith(b'\x1f\x8b'):
        raise RuntimeError('Restore the original Android boot first: backup is not a gzip Linux kernel')
    try:
        prefix = zlib.decompressobj(31).decompress(compressed, 64)
    except zlib.error as error:
        raise RuntimeError('Invalid Android kernel gzip') from error
    if len(prefix) != 64 or prefix[56:60] != b'ARM\x64':
        raise RuntimeError('Backup does not contain the expected ARM64 Linux kernel')


def checked_backup(state):
    backup = SHARED / 'ANDROID-BOOT-BACKUP.img'
    verify_file(backup, state['original_boot_sha256'], SIZE)
    assert_android_backup(backup)
    if boot_identity(backup) != boot_identity(KIT / UEFI_NAME):
        raise RuntimeError('Backup DTB / active addresses differ from the audited UEFI candidate')
    return backup


def restore_verified(device, backup, original_sha):
    verify_file(backup, original_sha, SIZE)
    device.write(backup)
    if device.digest() != original_sha:
        raise RuntimeError('ANDROID BOOT RESTORE VERIFICATION FAILED. Do not reboot; use TWRP.')


def install_verified(device, backup, payload, original_sha, payload_sha=PADDED_SHA):
    verify_file(backup, original_sha, SIZE)
    verify_file(payload, payload_sha, SIZE)
    current = device.digest()
    if current == payload_sha:
        return 'already-written'
    if current != original_sha:
        raise RuntimeError('Current boot changed since backup; refusing to overwrite it')
    try:
        device.write(payload)
        if device.digest() != payload_sha:
            raise RuntimeError('UEFI boot readback mismatch')
    except BaseException as error:
        try:
            restore_verified(device, backup, original_sha)
        except BaseException as rollback_error:
            raise RuntimeError('Boot write failed AND rollback failed. Do not reboot; restore in TWRP.') from rollback_error
        raise RuntimeError('Boot write failed; original Android boot restored and verified. No reboot.') from error
    return 'written-and-verified'


def write_recovery_script(sha):
    # The private backup hash is embedded locally, never in the public package.
    script = r'''#!/sbin/sh
set -eu
cd /data/media/0/DBY-UEFI-REPORT-03
EXPECTED='__SHA__'
ACTUAL=$(sha256sum ANDROID-BOOT-BACKUP.img)
ACTUAL=${ACTUAL%% *}
[ "$ACTUAL" = "$EXPECTED" ] || { echo 'Backup SHA256 mismatch. STOP.'; exit 1; }
TARGET=''
for CANDIDATE in /dev/block/by-name/boot /dev/block/bootdevice/by-name/boot; do
  if [ -b "$CANDIDATE" ]; then
    FOUND=$(readlink -f "$CANDIDATE")
    if [ -n "$TARGET" ] && [ "$TARGET" != "$FOUND" ]; then echo 'Ambiguous boot target. STOP.'; exit 1; fi
    TARGET=$FOUND
  fi
done
[ -n "$TARGET" ] || { echo 'boot partition missing. STOP.'; exit 1; }
BYTES=$(blockdev --getsize64 "$TARGET")
[ "$BYTES" = 100663296 ] || { echo 'Unexpected boot size. STOP.'; exit 1; }
dd if=ANDROID-BOOT-BACKUP.img of="$TARGET" bs=4194304
sync
ACTUAL=$(sha256sum "$TARGET")
ACTUAL=${ACTUAL%% *}
[ "$ACTUAL" = "$EXPECTED" ] || { echo 'RESTORE FAILED. Stay in recovery.'; exit 1; }
echo 'Original Android boot restored and verified. You may reboot System.'
'''.replace('__SHA__', sha)
    target = SHARED / 'RESTORE-ANDROID-IN-TWRP.sh'
    if target.is_symlink():
        raise RuntimeError('Recovery script path is a symlink')
    target.write_text(script)
    target.chmod(0o644)


def prepare():
    identity = check_android_device()
    device = BootDevice()
    recovery = check_recovery_independence(device.path)
    verify_file(KIT / UEFI_NAME, UEFI_SHA, 10022912)
    SHARED.mkdir(parents=True, exist_ok=True)
    if SHARED.resolve() != SHARED:
        raise RuntimeError('Shared backup folder must not be a symlink')
    SHARED.chmod(0o755)
    if STATE.exists():
        state = json.loads(STATE.read_text())
        checked_backup(state)
        if state.get('recovery') != recovery:
            raise RuntimeError('Recovery changed since preparation; leaving the backup untouched')
        if device.digest() != state['original_boot_sha256']:
            raise RuntimeError('Existing backup retained; boot is no longer the original image. Restore first.')
        print('Existing backup is valid; it has not been overwritten.')
    else:
        if (SHARED / 'ANDROID-BOOT-BACKUP.img').exists():
            raise RuntimeError('A backup exists without private state. Leaving it untouched.')
        if shutil.disk_usage(SHARED).free < 384 * 1024 * 1024:
            raise RuntimeError('At least 384 MiB free space is required')
        temporary = SHARED / ('backup-partial-' + str(time.time_ns()))
        try:
            device.copy_to(temporary)
            if temporary.stat().st_size != SIZE:
                raise RuntimeError('Short backup')
            assert_android_backup(temporary)
            if boot_identity(temporary) != boot_identity(KIT / UEFI_NAME):
                raise RuntimeError('Current boot DTB / addresses do not match this UEFI candidate')
            sha = digest_file(temporary)
            if device.digest() != sha:
                raise RuntimeError('boot changed while being backed up')
            backup = SHARED / 'ANDROID-BOOT-BACKUP.img'
            temporary.rename(backup)
            state = dict(original_boot_sha256=sha, boot_partition_bytes=SIZE,
                         device=identity, recovery=recovery, current_kernel=os.uname().release,
                         uefi_image_sha256=UEFI_SHA, padded_test_sha256=PADDED_SHA)
            atomic_json(STATE, state)
        finally:
            if temporary.exists():
                temporary.unlink()
    payload = SHARED / 'UEFI-TEST-BOOT.img'
    if payload.exists():
        verify_file(payload, PADDED_SHA, SIZE)
    else:
        temporary = SHARED / ('uefi-partial-' + str(time.time_ns()))
        try:
            with temporary.open('xb') as stream, (KIT / UEFI_NAME).open('rb') as src:
                shutil.copyfileobj(src, stream)
                remaining = SIZE - stream.tell()
                while remaining:
                    n = min(1024 * 1024, remaining)
                    stream.write(bytes(n))
                    remaining -= n
                stream.flush()
                os.fsync(stream.fileno())
            verify_file(temporary, PADDED_SHA, SIZE)
            temporary.rename(payload)
        finally:
            if temporary.exists():
                temporary.unlink()
    write_recovery_script(state['original_boot_sha256'])
    atomic_json(SHARED / 'prepare-state.json', state)
    (SHARED / 'ANDROID-BOOT-BACKUP.img.sha256').write_text(state['original_boot_sha256'] + '  ANDROID-BOOT-BACKUP.img\n')
    os.sync()
    print('PREPARED. No block partitions flashed; no reboot requested.')
    print('In TWRP, verify that /sdcard/DBY-UEFI-REPORT-03/ANDROID-BOOT-BACKUP.img is visible (96 MiB).')
    print('Then return to Android and run: python uefi_test.py start --recovery-checked --rescue-ready')


def load_state():
    if not STATE.is_file():
        raise RuntimeError('Run prepare first; private state is missing')
    return json.loads(STATE.read_text())


def start(recovery_checked):
    if not recovery_checked:
        raise RuntimeError('First verify the new backup is accessible in TWRP; then use --recovery-checked')
    check_android_device()
    device = BootDevice()
    state = load_state()
    if check_recovery_independence(device.path) != state.get('recovery'):
        raise RuntimeError('Recovery changed after preparation; refusing boot write')
    backup = checked_backup(state)
    verify_file(KIT / UEFI_NAME, UEFI_SHA, 10022912)
    payload = SHARED / 'UEFI-TEST-BOOT.img'
    atomic_json(SHARED / 'start-state.json', dict(stage='before-write', hardware_boot_observed=False))
    result = install_verified(device, backup, payload, state['original_boot_sha256'])
    try:
        atomic_json(SHARED / 'start-state.json', dict(stage=result, reboot_requested=True,
                    note='A verified boot write is NOT evidence of UEFI execution'))
        os.sync()
        subprocess.run(['/system/bin/reboot'], check=True)
    except BaseException as error:
        restore_verified(device, backup, state['original_boot_sha256'])
        raise RuntimeError('Reboot or final logging failed; original Android boot restored.') from error


def restore():
    check_android_device()
    device = BootDevice()
    state = load_state()
    backup = checked_backup(state)
    if device.digest() != state['original_boot_sha256']:
        restore_verified(device, backup, state['original_boot_sha256'])
    os.sync()
    print('Original Android boot is present and SHA256-verified. No reboot requested.')


def report():
    check_android_device()
    device = BootDevice()
    state = load_state()
    print('Describe the UEFI screen (menu, Shell, ACPI, LBA0 read results, USB and keys), or say black screen:')
    observations = input().strip()
    result = dict(current_kernel=os.uname().release, current_boot_sha256=device.digest(),
                  android_boot_restored=False, observed_by_user=observations,
                  uefi_logs_automatically_captured=False,
                  boot_reason=prop('ro.boot.bootreason'))
    result['android_boot_restored'] = result['current_boot_sha256'] == state['original_boot_sha256']
    atomic_json(SHARED / 'runtime-report.json', result)
    archive = SHARED / ('UEFI-report-' + str(time.time_ns()) + '.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        for name in ('prepare-state.json', 'start-state.json', 'runtime-report.json'):
            p = SHARED / name
            if p.is_file() and not p.is_symlink():
                if p.stat().st_size > 65536:
                    raise RuntimeError('Unexpected report size; no raw images will be archived')
                json.loads(p.read_text())
                tar.add(p, arcname=name)
    archive.chmod(0o644)
    print('Send this small report (it contains NO partition images): /sdcard/DBY-UEFI-REPORT-03/' + archive.name)


def install_report_service(base=None, service=None):
    # APatch and Magisk both execute /data/adb/service.d at late_start.
    base = Path('/data/adb/dby-uefi-report') if base is None else Path(base)
    service = Path('/data/adb/service.d/95-dby-uefi-report.sh') if service is None else Path(service)
    if base.is_symlink() or service.is_symlink() or service.parent.is_symlink():
        raise RuntimeError('Unexpected symlink at reporting service path')
    if not service.parent.parent.is_dir():
        raise RuntimeError('Root service storage /data/adb is unavailable')
    service.parent.mkdir(mode=0o700, exist_ok=True)
    base.mkdir(mode=0o700, exist_ok=True)
    shutil.copyfile(KIT / 'collect-after-boot.sh', base / 'collect.sh')
    (base / 'collect.sh').chmod(0o700)
    service.write_text('#!/system/bin/sh\n' + shlex.quote(str(base / 'collect.sh')) + ' &\n')
    service.chmod(0o700)



def collect_reports_now():
    install_report_service()
    base = Path('/data/adb/dby-uefi-report')
    (base / 'pending').touch(mode=0o600)
    subprocess.run(['/system/bin/sh', str(base / 'collect.sh'), '--now'], check=True)
    print('Available Android-side reports: /sdcard/reports_uefi/')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'start', 'restore', 'report', 'collect'])
    parser.add_argument('--recovery-checked', action='store_true')
    parser.add_argument('--rescue-ready', action='store_true', help='Rescue ZIP 03 is downloaded on the second smartphone')
    args = parser.parse_args()
    if os.geteuid() != 0:
        command = shlex.join([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]])
        return subprocess.call(['su', '-c', command])
    with (KIT / '.uefi-test.lock').open('a') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another UEFI test operation is already running')
        if args.action == 'prepare':
            install_report_service()
            prepare()
        elif args.action == 'start':
            if not args.rescue_ready:
                raise RuntimeError('Download the matching rescue ZIP 03 on the second smartphone first; then use --rescue-ready')
            install_report_service()
            (Path('/data/adb/dby-uefi-report') / 'pending').touch(mode=0o600)
            start(args.recovery_checked)
        elif args.action == 'restore':
            restore()
        elif args.action == 'collect':
            collect_reports_now()
        else:
            report()
            collect_reports_now()
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, ValueError, KeyError, subprocess.SubprocessError, EOFError) as error:
        print('STOP:', error, file=sys.stderr)
        raise SystemExit(1)
