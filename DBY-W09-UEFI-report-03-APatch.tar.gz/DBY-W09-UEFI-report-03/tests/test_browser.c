#include <stddef.h>
#include <assert.h>
typedef __WCHAR_TYPE__ CHAR16;typedef size_t UINTN;typedef int BOOLEAN;
#define STATIC static
#define VOID void
#define CONST const
static size_t StrLen(const CHAR16*s){size_t n=0;while(s[n])n++;return n;}
STATIC BOOLEAN DbyIsEfi (CONST CHAR16 *Name) {
  UINTN N = StrLen (Name);
  return N >= 4 && Name[N-4] == L'.' && (Name[N-3] == L'E' || Name[N-3] == L'e') &&
    (Name[N-2] == L'F' || Name[N-2] == L'f') && (Name[N-1] == L'I' || Name[N-1] == L'i');
}
STATIC VOID DbyParent (CHAR16 *Path) {
  UINTN N = StrLen (Path);
  while (N > 1 && Path[N-1] != L'\\') { Path[--N] = 0; }
  if (N > 1) { Path[N-1] = 0; }
}

int main(void){
 assert(DbyIsEfi(L"BOOTAA64.EFI"));assert(DbyIsEfi(L"a.eFi"));
 assert(!DbyIsEfi(L"efi"));assert(!DbyIsEfi(L"foo.efi.bak"));assert(!DbyIsEfi(L""));
 CHAR16 a[]=L"\\EFI\\BOOT";DbyParent(a);assert(StrLen(a)==4);DbyParent(a);assert(StrLen(a)==1);DbyParent(a);assert(StrLen(a)==1);
 CHAR16 e[]=L"";DbyParent(e);assert(StrLen(e)==0);return 0;
}
