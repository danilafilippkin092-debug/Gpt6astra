import unittest,tempfile,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('service',Path(__file__).resolve().parent.parent/'uefi_test.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ServiceTests(unittest.TestCase):
 def test_apatch_missing_service_directory_created(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);base=r/'report';service=r/'service.d/95-dby-uefi-report.sh';m.install_report_service(base,service)
   self.assertTrue(service.is_file());self.assertEqual(service.stat().st_mode&0o777,0o700);self.assertTrue((base/'collect.sh').is_file())
   m.install_report_service(base,service)
 def test_service_directory_symlink_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);(r/'real').mkdir();(r/'service.d').symlink_to(r/'real',target_is_directory=True)
   with self.assertRaisesRegex(RuntimeError,'symlink'):m.install_report_service(r/'report',r/'service.d/test')
