import os,unittest,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('guard',Path(__file__).resolve().parent.parent/'uefi_test.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class AndroidBackupGuard(unittest.TestCase):
 def test_raw_uefi_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'original Android boot first'):m.assert_android_backup(m.KIT/m.UEFI_NAME)
 @unittest.skipUnless(os.environ.get('KNOWN_BOOT_IMAGE'),'private original boot fixture unavailable')
 def test_original_linux_accepted(self):m.assert_android_backup(os.environ['KNOWN_BOOT_IMAGE'])
