/** @file
  DBY-W09 interactive experimental UEFI environment.
  Copyright (c) DuoWoA authors and Microsoft Corporation.
  SPDX-License-Identifier: BSD-2-Clause-Patent
**/
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DebugLib.h>
#include <Library/DeviceBootManagerLib.h>
#include <Library/DevicePathLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/PlatformBootManagerLib.h>
#include <Library/PrintLib.h>
#include <Library/UefiBootManagerLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Guid/Acpi.h>
#include <Guid/FileInfo.h>
#include <Protocol/BlockIo.h>
#include <Protocol/DevicePath.h>
#include <Protocol/FirmwareVolume2.h>
#include <Protocol/GraphicsOutput.h>
#include <Protocol/LoadedImage.h>
#include <Protocol/SimpleFileSystem.h>
#include <Protocol/SimpleTextInEx.h>
#include <Protocol/UsbIo.h>
#include <Pi/PiFirmwareFile.h>
#include <Configuration/BootDevices.h>


// Stage journal starts at BDS. No Android encrypted filesystem access.
STATIC CHAR8 mStageLog[16384];
STATIC UINTN mStageBytes;
STATIC EFI_FILE_PROTOCOL *mUsbLog;
STATIC VOID DbyStage (CONST CHAR8 *Stage, EFI_STATUS Status) {
  UINTN N;
  if (mStageBytes < sizeof(mStageLog)-128) {
    N = AsciiSPrint(mStageLog+mStageBytes,sizeof(mStageLog)-mStageBytes,"%a: %r\r\n",Stage,Status);
    mStageBytes += N;
  }
  DEBUG((DEBUG_ERROR,"DBY03 %a: %r\n",Stage,Status));
  if (gST->ConOut != NULL) { Print(L"[DBY03] %a: %r\r\n",Stage,Status); }
  if (mUsbLog != NULL) {
    mUsbLog->SetPosition(mUsbLog,0); N=mStageBytes;
    if (!EFI_ERROR(mUsbLog->Write(mUsbLog,&N,mStageLog))) { mUsbLog->Flush(mUsbLog); }
  }
}
STATIC VOID DbyUsbJournal (VOID) {
  EFI_HANDLE *Handles=NULL; UINTN Count=0,I,J;
  EFI_DEVICE_PATH_PROTOCOL *Node; BOOLEAN Usb;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs; EFI_FILE_PROTOCOL *Root,*Dir,*Existing;
  EFI_STATUS Status; CHAR16 Name[40];
  if (mUsbLog != NULL) { return; }
  if (EFI_ERROR(gBS->LocateHandleBuffer(ByProtocol,&gEfiSimpleFileSystemProtocolGuid,NULL,&Count,&Handles))) { return; }
  for(I=0;I<Count && mUsbLog==NULL;I++) {
    Node=DevicePathFromHandle(Handles[I]); Usb=FALSE;
    if(Node==NULL){continue;}
    while(!IsDevicePathEnd(Node)) {
      if(DevicePathType(Node)==MESSAGING_DEVICE_PATH &&
         (DevicePathSubType(Node)==MSG_USB_DP || DevicePathSubType(Node)==MSG_USB_CLASS_DP || DevicePathSubType(Node)==MSG_USB_WWID_DP)){Usb=TRUE;}
      Node=NextDevicePathNode(Node);
    }
    if(!Usb){continue;}
    if(EFI_ERROR(gBS->HandleProtocol(Handles[I],&gEfiSimpleFileSystemProtocolGuid,(VOID**)&Fs))){continue;}
    if(EFI_ERROR(Fs->OpenVolume(Fs,&Root))){continue;}
    Status=Root->Open(Root,&Dir,L"reports_uefi",EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE,EFI_FILE_DIRECTORY);
    Root->Close(Root); if(EFI_ERROR(Status)){continue;}
    for(J=0;J<1000;J++) {
      UnicodeSPrint(Name,sizeof(Name),L"UEFI03-%03u.log",(UINT32)J);
      Status=Dir->Open(Dir,&Existing,Name,EFI_FILE_MODE_READ,0);
      if(!EFI_ERROR(Status)){Existing->Close(Existing);continue;}
      if(Status!=EFI_NOT_FOUND){break;}
      Status=Dir->Open(Dir,&mUsbLog,Name,EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE,0);
      if(EFI_ERROR(Status)){mUsbLog=NULL;}
      break;
    }
    Dir->Close(Dir);
  }
  FreePool(Handles);
  DbyStage(mUsbLog!=NULL?"USB journal connected":"USB journal unavailable",mUsbLog!=NULL?EFI_SUCCESS:EFI_NOT_FOUND);
}

#define DBY_MAX_FILES 128
#define DBY_MAX_NAME 256
#define DBY_MAX_PATH 1024
STATIC CONST EFI_GUID mShellGuid = {0x7c04a583,0x9e3e,0x4f1c,{0xad,0x65,0xe0,0x52,0x68,0xd0,0xb4,0xd1}};
STATIC CONST EFI_GUID mBootMenuGuid = {0xeec25bdc,0x67f2,0x4d95,{0xb1,0xd5,0xf8,0x1b,0x20,0x39,0xd1,0x1d}};

typedef struct { CHAR16 Name[DBY_MAX_NAME]; BOOLEAN Directory; } DBY_FILE;

STATIC EFI_STATUS DbyReadKey (EFI_INPUT_KEY *Key) {
  EFI_STATUS Status;
  for (;;) {
    if (gST->ConIn != NULL) {
      Status = gST->ConIn->ReadKeyStroke (gST->ConIn, Key);
      if (!EFI_ERROR (Status)) { return EFI_SUCCESS; }
      if (Status != EFI_NOT_READY) { return Status; }
    }
    gBS->Stall (30000);
  }
}
STATIC VOID DbyPause (VOID) {
  EFI_INPUT_KEY Key;
  Print (L"\r\nPress Power/Enter to return.\r\n");
  while (!EFI_ERROR (DbyReadKey (&Key))) {
    if (Key.UnicodeChar == CHAR_CARRIAGE_RETURN || Key.ScanCode == SCAN_ESC) { return; }
  }
}
STATIC VOID DbyClear (VOID) {
  if (gST->ConOut != NULL) {
    gST->ConOut->SetAttribute (gST->ConOut, EFI_LIGHTGRAY | EFI_BACKGROUND_BLUE);
    gST->ConOut->ClearScreen (gST->ConOut);
  }
}
STATIC UINTN DbyChoose (CONST CHAR16 *Title, CONST CHAR16 **Items, UINTN Count) {
  UINTN Choice = 0, First, I;
  EFI_INPUT_KEY Key;
  if (Count == 0) { return MAX_UINTN; }
  for (;;) {
    DbyClear ();
    Print (L"DBY-W09 EXPERIMENTAL UEFI 03\r\n%s\r\n\r\n", Title);
    Print (L"Volume +/-: move   Power/Enter: select   USB keyboard supported\r\n");
    Print (L"Experimental core ACPI only; Windows device support is incomplete.\r\n\r\n");
    First = (Choice / 12) * 12;
    for (I = First; I < Count && I < First + 12; I++) {
      Print (L"%s %3u  %s\r\n", I == Choice ? L">" : L" ", (UINT32)I, Items[I]);
    }
    Print (L"\r\nSelection %u / %u\r\n", (UINT32)(Choice + 1), (UINT32)Count);
    if (EFI_ERROR (DbyReadKey (&Key))) { return MAX_UINTN; }
    if (Key.ScanCode == SCAN_UP) { Choice = Choice ? Choice - 1 : Count - 1; }
    else if (Key.ScanCode == SCAN_DOWN) { Choice = (Choice + 1) % Count; }
    else if (Key.ScanCode == SCAN_ESC) { return MAX_UINTN; }
    else if (Key.UnicodeChar == CHAR_CARRIAGE_RETURN) { return Choice; }
  }
}
STATIC VOID DbyFixConsole (VOID) {
  EFI_HANDLE *Handles = NULL; UINTN Count = 0, I; EFI_DEVICE_PATH_PROTOCOL *Path;
  EfiBootManagerConnectAll ();
  if (!EFI_ERROR (gBS->LocateHandleBuffer (ByProtocol, &gEfiSimpleTextInputExProtocolGuid, NULL, &Count, &Handles))) {
    for (I = 0; I < Count; I++) {
      Path = DevicePathFromHandle (Handles[I]);
      if (Path != NULL) { EfiBootManagerUpdateConsoleVariable (ConIn, Path, NULL); }
      gBS->ConnectController (Handles[I], NULL, NULL, TRUE);
    }
    FreePool (Handles);
  }
  EfiBootManagerConnectAll ();
  // Some ConsoleSplitter handles expose text only; HII applications need GOP too.
  if (gST->ConsoleOutHandle != NULL) {
    EFI_GRAPHICS_OUTPUT_PROTOCOL *Gop = NULL;
    if (EFI_ERROR (gBS->HandleProtocol (gST->ConsoleOutHandle, &gEfiGraphicsOutputProtocolGuid, (VOID **)&Gop))) {
      if (!EFI_ERROR (gBS->LocateProtocol (&gEfiGraphicsOutputProtocolGuid, NULL, (VOID **)&Gop)) && Gop != NULL) {
        gBS->InstallProtocolInterface (&gST->ConsoleOutHandle, &gEfiGraphicsOutputProtocolGuid, EFI_NATIVE_INTERFACE, Gop);
      }
    }
  }
}
STATIC EFI_STATUS DbyRunImage (EFI_DEVICE_PATH_PROTOCOL *Path, VOID *Buffer, UINTN Size, CONST CHAR16 *Options) {
  EFI_HANDLE Image = NULL; EFI_STATUS Status; EFI_LOADED_IMAGE_PROTOCOL *Loaded = NULL;
  UINTN ExitSize = 0; CHAR16 *ExitData = NULL; VOID *OptionBuffer = NULL;
  if (Path == NULL) { return EFI_INVALID_PARAMETER; }
  DbyStage("LoadImage begin",EFI_SUCCESS);
  Status = gBS->LoadImage (FALSE, gImageHandle, Path, Buffer, Size, &Image);
  DbyStage("LoadImage result",Status);
  if (EFI_ERROR (Status)) { return Status; }
  if (Options != NULL) {
    Status = gBS->HandleProtocol (Image, &gEfiLoadedImageProtocolGuid, (VOID **)&Loaded);
    if (EFI_ERROR (Status)) { gBS->UnloadImage (Image); return Status; }
    OptionBuffer = AllocateCopyPool (StrSize (Options), Options);
    if (OptionBuffer == NULL) { gBS->UnloadImage (Image); return EFI_OUT_OF_RESOURCES; }
    Loaded->LoadOptions = OptionBuffer;
    Loaded->LoadOptionsSize = (UINT32)StrSize (Options);
  }
  if (Buffer == NULL) { EfiSignalEventReadyToBoot (); }
  DbyStage("StartImage begin",EFI_SUCCESS);
  Status = gBS->StartImage (Image, &ExitSize, &ExitData);
  DbyStage("StartImage returned",Status);
  if (ExitData != NULL) { FreePool (ExitData); }
  gBS->UnloadImage (Image);
  if (OptionBuffer != NULL) { FreePool (OptionBuffer); }
  return Status;
}
STATIC EFI_STATUS DbyRunFv (CONST EFI_GUID *Guid, CONST CHAR16 *Options) {
  EFI_HANDLE *Handles = NULL; UINTN Count = 0, I; EFI_STATUS Status = EFI_NOT_FOUND;
  EFI_FIRMWARE_VOLUME2_PROTOCOL *Fv; VOID *Buffer; UINTN Size; UINT32 Auth;
  EFI_DEVICE_PATH_PROTOCOL *Path, *Parent; MEDIA_FW_VOL_FILEPATH_DEVICE_PATH Node;
  Status = gBS->LocateHandleBuffer (ByProtocol, &gEfiFirmwareVolume2ProtocolGuid, NULL, &Count, &Handles);
  if (EFI_ERROR (Status)) { return Status; }
  Status = EFI_NOT_FOUND;
  for (I = 0; I < Count; I++) {
    if (EFI_ERROR (gBS->HandleProtocol (Handles[I], &gEfiFirmwareVolume2ProtocolGuid, (VOID **)&Fv))) { continue; }
    Buffer = NULL; Size = 0; Auth = 0;
    if (EFI_ERROR (Fv->ReadSection (Fv, Guid, EFI_SECTION_PE32, 0, &Buffer, &Size, &Auth))) { continue; }
    Parent = DevicePathFromHandle (Handles[I]);
    if (Parent == NULL) { FreePool (Buffer); continue; }
    ZeroMem (&Node, sizeof (Node));
    Node.Header.Type = MEDIA_DEVICE_PATH; Node.Header.SubType = MEDIA_PIWG_FW_FILE_DP;
    SetDevicePathNodeLength (&Node.Header, sizeof (Node)); CopyGuid (&Node.FvFileName, Guid);
    Path = AppendDevicePathNode (Parent, (EFI_DEVICE_PATH_PROTOCOL *)&Node);
    if (Path != NULL) { Status = DbyRunImage (Path, Buffer, Size, Options); FreePool (Path); }
    else { Status = EFI_OUT_OF_RESOURCES; }
    FreePool (Buffer); break;
  }
  FreePool (Handles); return Status;
}
STATIC BOOLEAN DbyIsEfi (CONST CHAR16 *Name) {
  UINTN N = StrLen (Name);
  return N >= 4 && Name[N-4] == L'.' && (Name[N-3] == L'E' || Name[N-3] == L'e') &&
    (Name[N-2] == L'F' || Name[N-2] == L'f') && (Name[N-1] == L'I' || Name[N-1] == L'i');
}
STATIC VOID DbyParent (CHAR16 *Path) {
  UINTN N = StrLen (Path);
  while (N > 1 && Path[N-1] != L'\\') { Path[--N] = 0; }
  if (N > 1) { Path[N-1] = 0; }
}
STATIC VOID DbyBrowseVolume (EFI_HANDLE Handle) {
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs; EFI_FILE_PROTOCOL *Root, *Directory;
  EFI_FILE_INFO *Info; DBY_FILE *Files; CONST CHAR16 **Labels;
  UINTN Count, Size, I, Choice, N; CHAR16 Current[DBY_MAX_PATH], Next[DBY_MAX_PATH];
  EFI_STATUS Status; EFI_DEVICE_PATH_PROTOCOL *ImagePath;
  if (EFI_ERROR (gBS->HandleProtocol (Handle, &gEfiSimpleFileSystemProtocolGuid, (VOID **)&Fs))) { return; }
  Status = Fs->OpenVolume (Fs, &Root);
  if (EFI_ERROR (Status)) { Print (L"OpenVolume: %r\r\n", Status); DbyPause (); return; }
  Files = AllocateZeroPool (sizeof (*Files) * DBY_MAX_FILES);
  Labels = AllocateZeroPool (sizeof (*Labels) * (DBY_MAX_FILES + 1));
  Info = AllocateZeroPool (4096);
  if (Files == NULL || Labels == NULL || Info == NULL) {
    if (Files != NULL) { FreePool (Files); } if (Labels != NULL) { FreePool (Labels); }
    if (Info != NULL) { FreePool (Info); } Root->Close (Root); return;
  }
  StrCpyS (Current, DBY_MAX_PATH, L"\\");
  for (;;) {
    Directory = NULL; Count = 0;
    Status = Root->Open (Root, &Directory, Current, EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR (Status)) { Print (L"Open %s: %r\r\n", Current, Status); DbyPause (); break; }
    for (;;) {
      Size = 4096; ZeroMem (Info, Size);
      Status = Directory->Read (Directory, &Size, Info);
      if (EFI_ERROR (Status) || Size == 0) { break; }
      if (Size < OFFSET_OF (EFI_FILE_INFO, FileName) + sizeof (CHAR16) || Info->Size > Size || Info->Size < OFFSET_OF (EFI_FILE_INFO, FileName) + sizeof (CHAR16)) { Status = EFI_VOLUME_CORRUPTED; break; }
      N = StrnLenS (Info->FileName, (Size - OFFSET_OF (EFI_FILE_INFO, FileName)) / sizeof (CHAR16));
      if (N == 0 || N >= DBY_MAX_NAME || StrCmp (Info->FileName,L".") == 0 || StrCmp (Info->FileName,L"..") == 0) { continue; }
      if (!(Info->Attribute & EFI_FILE_DIRECTORY) && !DbyIsEfi (Info->FileName)) { continue; }
      if (Count == DBY_MAX_FILES) { Status = EFI_BUFFER_TOO_SMALL; break; }
      StrCpyS (Files[Count].Name, DBY_MAX_NAME, Info->FileName);
      Files[Count].Directory = (Info->Attribute & EFI_FILE_DIRECTORY) != 0; Count++;
    }
    Directory->Close (Directory);
    if (EFI_ERROR (Status)) { Print (L"Directory read/entry limit: %r (showing %u entries)\r\n",Status,(UINT32)Count); DbyPause (); }
    Labels[0] = StrLen(Current) == 1 ? L"Back to filesystem list" : L".. (parent directory)";
    for (I = 0; I < Count; I++) { Labels[I+1] = Files[I].Name; }
    Choice = DbyChoose (Current, Labels, Count+1);
    if (Choice == MAX_UINTN || Choice == 0) {
      if (StrLen(Current) == 1 || Choice == MAX_UINTN) { break; }
      DbyParent (Current); continue;
    }
    I = Choice - 1;
    if (StrLen(Current) + StrLen(Files[I].Name) + 2 >= DBY_MAX_PATH) { Print (L"Path too long\r\n"); DbyPause (); continue; }
    StrCpyS (Next, DBY_MAX_PATH, Current);
    if (StrLen(Next) > 1) { StrCatS (Next, DBY_MAX_PATH, L"\\"); }
    StrCatS (Next, DBY_MAX_PATH, Files[I].Name);
    if (Files[I].Directory) { StrCpyS(Current,DBY_MAX_PATH,Next); continue; }
    ImagePath = FileDevicePath (Handle, Next);
    DbyClear (); Print (L"Launching %s\r\n",Next);
    Status = ImagePath == NULL ? EFI_OUT_OF_RESOURCES : DbyRunImage (ImagePath,NULL,0,NULL);
    if (ImagePath != NULL) { FreePool (ImagePath); }
    Print (L"EFI application returned: %r\r\n",Status); DbyPause ();
  }
  FreePool (Info); FreePool (Labels); FreePool (Files); Root->Close (Root);
}
STATIC VOID DbyBrowse (VOID) {
  EFI_HANDLE *Handles = NULL; UINTN Count = 0, I, Choice; EFI_STATUS Status;
  CONST CHAR16 *Labels[33]; CHAR16 Names[32][40];
  Status = gBS->LocateHandleBuffer(ByProtocol,&gEfiSimpleFileSystemProtocolGuid,NULL,&Count,&Handles);
  if (EFI_ERROR(Status) || Count == 0) { Print(L"No UEFI-readable filesystem. Android encrypted userdata is not FAT.\r\n"); DbyPause(); return; }
  Labels[0]=L"Back"; if (Count>32) { Count=32; }
  for(I=0;I<Count;I++){UnicodeSPrint(Names[I],sizeof(Names[I]),L"Filesystem %u",(UINT32)I);Labels[I+1]=Names[I];}
  for(;;){Choice=DbyChoose(L"EFI file browser (FAT USB/ESP)",Labels,Count+1);if(Choice==0||Choice==MAX_UINTN){break;}DbyBrowseVolume(Handles[Choice-1]);}
  FreePool(Handles);
}
STATIC VOID DbyDiagnostics (VOID) {
  EFI_GRAPHICS_OUTPUT_PROTOCOL *Gop = NULL; EFI_HANDLE *Handles = NULL;
  UINTN Count=0,I,Pages,Alignment; EFI_BLOCK_IO_PROTOCOL *Block; VOID *Buffer; EFI_STATUS Status; VOID *Acpi=NULL;
  DbyClear();
  Status=gBS->LocateProtocol(&gEfiGraphicsOutputProtocolGuid,NULL,(VOID**)&Gop);
  if(!EFI_ERROR(Status)&&Gop!=NULL&&Gop->Mode!=NULL&&Gop->Mode->Info!=NULL){Print(L"GOP: %u x %u stride=%u\r\n",Gop->Mode->Info->HorizontalResolution,Gop->Mode->Info->VerticalResolution,Gop->Mode->Info->PixelsPerScanLine);}
  else{Print(L"GOP unavailable: %r\r\n",Status);}
  Status=EfiGetSystemConfigurationTable(&gEfiAcpi20TableGuid,&Acpi);Print(L"ACPI 2.0 RSDP: %r\r\n",Status);
  Print(L"ACPI includes CPU/GIC/timers only; Windows peripherals unported.\r\n");
  Status=gBS->LocateHandleBuffer(ByProtocol,&gEfiUsbIoProtocolGuid,NULL,&Count,&Handles);
  Print(L"USB IO handles: %u (%r)\r\n",(UINT32)Count,Status);if(Handles!=NULL){FreePool(Handles);}
  Handles=NULL;Count=0;Status=gBS->LocateHandleBuffer(ByProtocol,&gEfiBlockIoProtocolGuid,NULL,&Count,&Handles);
  Print(L"Block IO handles: %u (%r)\r\n",(UINT32)Count,Status);
  if(!EFI_ERROR(Status)){
    for(I=0;I<Count;I++){
      Status=gBS->HandleProtocol(Handles[I],&gEfiBlockIoProtocolGuid,(VOID**)&Block);
      if(EFI_ERROR(Status)||Block==NULL||Block->Media==NULL){continue;}
      if(!Block->Media->MediaPresent){Print(L"%u: no media\r\n",(UINT32)I);continue;}
      if(Block->Media->BlockSize==0||Block->Media->BlockSize>65536){continue;}
      Alignment=MAX((UINTN)EFI_PAGE_SIZE,(UINTN)Block->Media->IoAlign);
      if(Alignment>0x100000||(Alignment&(Alignment-1))!=0){continue;}
      Pages=EFI_SIZE_TO_PAGES(Block->Media->BlockSize);Buffer=AllocateAlignedPages(Pages,Alignment);
      if(Buffer==NULL){continue;}
      Status=Block->ReadBlocks(Block,Block->Media->MediaId,0,Block->Media->BlockSize,Buffer);
      Print(L"%u: LBA0 read=%r block=%u last=%lu logical=%u\r\n",(UINT32)I,Status,Block->Media->BlockSize,Block->Media->LastBlock,Block->Media->LogicalPartition);
      FreeAlignedPages(Buffer,Pages);
    }
    FreePool(Handles);
  }
  DbyPause();
}
STATIC VOID DbyMenu (VOID) {
  STATIC CONST CHAR16 *Items[]={L"Browse filesystems / launch EFI file",L"UEFI Shell (USB keyboard; exit returns here)",L"Standard UEFI Boot Manager",L"Diagnostics / read-only LBA0 storage probe",L"Reconnect USB and storage",L"Restart (returns to this UEFI until boot is restored)",L"Power off (platform behavior untested)"};
  UINTN Choice;EFI_STATUS Status;
  DbyStage("menu entry",EFI_SUCCESS);gBS->SetWatchdogTimer(0,0,0,NULL);
  DbyStage("connect consoles begin",EFI_SUCCESS);DbyFixConsole();DbyUsbJournal();DbyStage("connect consoles complete",EFI_SUCCESS);
  for(;;){
    Choice=DbyChoose(L"Main menu",Items,ARRAY_SIZE(Items));
    if(Choice==MAX_UINTN){gBS->Stall(200000);continue;}
    if(Choice==0){DbyBrowse();}
    else if(Choice==1){DbyClear();Print(L"Starting Shell; startup.nsh autorun is disabled. Type exit to return.\r\n");Status=DbyRunFv(&mShellGuid,L"-nostartup");Print(L"Shell returned: %r\r\n",Status);DbyPause();}
    else if(Choice==2){DbyClear();Status=DbyRunFv(&mBootMenuGuid,NULL);Print(L"Boot Manager returned: %r\r\n",Status);DbyPause();}
    else if(Choice==3){DbyDiagnostics();}
    else if(Choice==4){DbyStage("reconnect begin",EFI_SUCCESS);DbyFixConsole();DbyUsbJournal();DbyStage("reconnect complete",EFI_SUCCESS);}
    else{gRT->ResetSystem(Choice==5?EfiResetCold:EfiResetShutdown,EFI_SUCCESS,0,NULL);Print(L"Reset request returned; use hardware buttons if needed.\r\n");DbyPause();}
  }
}
VOID EFIAPI PlatformBootManagerBeforeConsole(VOID){
  DbyStage("before console / EndOfDxe begin",EFI_SUCCESS);
  gBS->SetWatchdogTimer(0,0,0,NULL);
  EfiEventGroupSignal(&gEfiEndOfDxeEventGroupGuid);DbyStage("EndOfDxe complete",EFI_SUCCESS);EfiBootManagerDispatchDeferredImages();DbyStage("deferred images complete",EFI_SUCCESS);
  EfiBootManagerUpdateConsoleVariable(ConIn,(EFI_DEVICE_PATH_PROTOCOL*)&KeypadDevicePath,NULL);
  EfiBootManagerUpdateConsoleVariable(ConOut,(EFI_DEVICE_PATH_PROTOCOL*)&DisplayDevicePath,NULL);
  EfiBootManagerUpdateConsoleVariable(ErrOut,(EFI_DEVICE_PATH_PROTOCOL*)&DisplayDevicePath,NULL);
  DbyStage("device console begin",EFI_SUCCESS);DeviceBootManagerBeforeConsole(NULL,NULL);DbyStage("device console complete",EFI_SUCCESS);
}
VOID EFIAPI PlatformBootManagerAfterConsole(VOID){DbyMenu();}
VOID EFIAPI PlatformBootManagerOnDemandConInConnect(VOID){DeviceBootManagerOnDemandConInConnect();}
VOID EFIAPI PlatformBootManagerProcessBootCompletion(OUT EFI_BOOT_MANAGER_LOAD_OPTION *BootOption){(VOID)BootOption;}
VOID EFIAPI PlatformBootManagerPriorityBoot(IN OUT UINT16 **BootNext){(VOID)BootNext;}
VOID EFIAPI PlatformBootManagerWaitCallback(IN UINT16 TimeoutRemain){(VOID)TimeoutRemain;}
VOID EFIAPI PlatformBootManagerUnableToBoot(VOID){DbyMenu();}

VOID EFIAPI PlatformBootManagerBdsEntry(VOID){
  // Secure Boot is disabled in this experimental profile. Do not register
  // removable-media key-enrollment callbacks. No boot options are auto-started.
  DbyStage("BDS entry",EFI_SUCCESS);DeviceBootManagerBdsEntry();DbyStage("device BDS complete",EFI_SUCCESS);
}
VOID EFIAPI PlatformBootManagerDeadloop(VOID){DbyMenu();}
