/** SPDX-License-Identifier: BSD-2-Clause-Patent **/
#include <Uefi.h>
#include <IndustryStandard/Acpi63.h>
#include <Protocol/AcpiTable.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/DebugLib.h>
#include "Tables.h"
EFI_STATUS EFIAPI DbyCoreAcpiEntry(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE *SystemTable) {
  EFI_ACPI_TABLE_PROTOCOL *Acpi; EFI_STATUS Status; UINTN Keys[4], Count=0, I;
  CONST UINT8 *Tables[]={mDbyDsdt,mDbyFadt,mDbyMadt,mDbyGtdt};
  UINTN Sizes[]={sizeof(mDbyDsdt),sizeof(mDbyFadt),sizeof(mDbyMadt),sizeof(mDbyGtdt)};
  (VOID)ImageHandle; (VOID)SystemTable;
  Status=gBS->LocateProtocol(&gEfiAcpiTableProtocolGuid,NULL,(VOID**)&Acpi);
  if(EFI_ERROR(Status)){return Status;}
  for(I=0;I<ARRAY_SIZE(Tables);I++){
    Status=Acpi->InstallAcpiTable(Acpi,(VOID*)Tables[I],Sizes[I],&Keys[Count]);
    if(EFI_ERROR(Status)){
      while(Count>0){Acpi->UninstallAcpiTable(Acpi,Keys[--Count]);}
      DEBUG((EFI_D_ERROR,"DBY core ACPI installation failed: %r\n",Status));return Status;
    }
    Count++;
  }
  DEBUG((EFI_D_INFO,"DBY experimental CPU/GIC/timer ACPI installed; peripheral ACPI incomplete\n"));
  return EFI_SUCCESS;
}
