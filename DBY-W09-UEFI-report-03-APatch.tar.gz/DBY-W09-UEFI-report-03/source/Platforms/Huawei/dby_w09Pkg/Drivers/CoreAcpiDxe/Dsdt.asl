// SPDX-License-Identifier: BSD-2-Clause-Patent
// CPU namespace only. No guessed storage, USB, GPIO or power-control AML.
DefinitionBlock ("", "DSDT", 2, "HWDBY ", "DBYCPU02", 2)
{
    Scope (\_SB)
    {
        Device (C000) { Name (_HID, "ACPI0007") Name (_UID, 0) Name (_STA, 0x0F) }
        Device (C001) { Name (_HID, "ACPI0007") Name (_UID, 1) Name (_STA, 0x0F) }
        Device (C002) { Name (_HID, "ACPI0007") Name (_UID, 2) Name (_STA, 0x0F) }
        Device (C003) { Name (_HID, "ACPI0007") Name (_UID, 3) Name (_STA, 0x0F) }
        Device (C004) { Name (_HID, "ACPI0007") Name (_UID, 4) Name (_STA, 0x0F) }
        Device (C005) { Name (_HID, "ACPI0007") Name (_UID, 5) Name (_STA, 0x0F) }
        Device (C006) { Name (_HID, "ACPI0007") Name (_UID, 6) Name (_STA, 0x0F) }
        Device (C007) { Name (_HID, "ACPI0007") Name (_UID, 7) Name (_STA, 0x0F) }
    }
}
