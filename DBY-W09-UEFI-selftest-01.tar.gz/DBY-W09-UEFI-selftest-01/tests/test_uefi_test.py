import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import json
import struct
import tarfile
import shutil
import os
import io

SCRIPT = Path(os.environ.get('UEFI_TEST_SCRIPT_PATH', str(Path(__file__).resolve().parent.parent/'uefi_test.py')))
spec = importlib.util.spec_from_file_location('uefi_test', SCRIPT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class FakeBoot:
    def __init__(self, content, corrupt_first=False, fail_all=False):
        self.content = content
        self.writes = []
        self.corrupt_first = corrupt_first
        self.fail_all = fail_all
    def digest(self):
        return hashlib.sha256(self.content).hexdigest()
    def write(self, path):
        self.writes.append(str(path))
        if self.fail_all:
            raise OSError('simulated unavailable boot storage')
        self.content = Path(path).read_bytes()
        if self.corrupt_first and len(self.writes) == 1:
            self.content = bytes(len(self.content))

class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.old = self.root / 'old.img'; self.old.write_bytes(b'A' * 4096)
        self.new = self.root / 'new.img'; self.new.write_bytes(b'B' * 4096)
        self.old_sha = m.digest_file(self.old); self.new_sha = m.digest_file(self.new)
        self.saved_size = m.SIZE; m.SIZE = 4096
    def tearDown(self):
        m.SIZE = self.saved_size; self.tmp.cleanup()
    def run_install(self, device):
        return m.install_verified(device, self.old, self.new, self.old_sha, self.new_sha)
    def test_changed_current_boot_causes_zero_writes(self):
        device = FakeBoot(b'C' * 4096)
        with self.assertRaisesRegex(RuntimeError, 'changed since backup'):
            self.run_install(device)
        self.assertEqual(device.writes, [])
    def test_modified_backup_causes_zero_writes(self):
        device = FakeBoot(b'A' * 4096); self.old.write_bytes(b'C' * 4096)
        with self.assertRaisesRegex(RuntimeError, 'SHA256 mismatch'):
            self.run_install(device)
        self.assertEqual(device.writes, [])
    def test_modified_payload_causes_zero_writes(self):
        device = FakeBoot(b'A' * 4096); self.new.write_bytes(b'C' * 4096)
        with self.assertRaisesRegex(RuntimeError, 'SHA256 mismatch'):
            self.run_install(device)
        self.assertEqual(device.writes, [])
    def test_short_payload_causes_zero_writes(self):
        device = FakeBoot(b'A' * 4096); self.new.write_bytes(b'B')
        with self.assertRaisesRegex(RuntimeError, 'Wrong file size'):
            self.run_install(device)
        self.assertEqual(device.writes, [])
    def test_failed_readback_restores_original(self):
        device = FakeBoot(b'A' * 4096, corrupt_first=True)
        with self.assertRaisesRegex(RuntimeError, 'original Android boot restored'):
            self.run_install(device)
        self.assertEqual(device.content, self.old.read_bytes())
        self.assertEqual(device.writes, [str(self.new), str(self.old)])
    def test_storage_failure_reports_failed_rollback(self):
        device = FakeBoot(b'A' * 4096, fail_all=True)
        with self.assertRaisesRegex(RuntimeError, 'rollback failed'):
            self.run_install(device)
        self.assertEqual(len(device.writes), 2)
    def test_success_writes_only_expected_image(self):
        device = FakeBoot(b'A' * 4096)
        self.assertEqual(self.run_install(device), 'written-and-verified')
        self.assertEqual(device.content, self.new.read_bytes())
        self.assertEqual(device.writes, [str(self.new)])
    def test_already_written_is_idempotent(self):
        device = FakeBoot(b'B' * 4096)
        self.assertEqual(self.run_install(device), 'already-written')
        self.assertEqual(device.writes, [])
    def test_start_without_recovery_check_stops_before_device_access(self):
        with self.assertRaisesRegex(RuntimeError, 'verify the new backup'):
            m.start(False)
    def test_regular_file_cannot_be_block_device(self):
        with mock.patch.object(m, 'Path', lambda *args: self.old):
            with self.assertRaisesRegex(RuntimeError, 'not a block device'):
                m.BootDevice()
    def test_original_and_candidate_have_matching_native_dtb(self):
        if not os.environ.get('KNOWN_BOOT_IMAGE'):
            self.skipTest('Private reference boot image not supplied')
        old = Path(os.environ['KNOWN_BOOT_IMAGE'])
        candidate = SCRIPT.parent / m.UEFI_NAME
        self.assertEqual(m.boot_identity(old), m.boot_identity(candidate))

    def test_partial_writes_are_completed(self):
        class ShortWriter:
            def __init__(self): self.data = bytearray()
            def write(self, block):
                count = min(3, len(block)); self.data.extend(block[:count]); return count
        writer = ShortWriter(); m.copy_all_writes(io.BytesIO(b'abcdefghij'), writer)
        self.assertEqual(bytes(writer.data), b'abcdefghij')
    def test_zero_progress_write_is_rejected(self):
        class ZeroWriter:
            def write(self, block): return 0
        with self.assertRaisesRegex(OSError, 'no progress'):
            m.copy_all_writes(io.BytesIO(b'abc'), ZeroWriter())

    def test_recovery_without_own_kernel_is_rejected(self):
        header = bytearray(4096); header[:8] = b'ANDROID!'
        struct.pack_into('<I', header, 36, 4096); struct.pack_into('<I', header, 40, 2)
        with self.assertRaisesRegex(RuntimeError, 'lacks its own kernel'):
            m.recovery_header_check(header, 100663296)
    def test_independent_recovery_header_is_accepted(self):
        header = bytearray(4096); header[:8] = b'ANDROID!'
        struct.pack_into('<I', header, 8, 8388608)
        struct.pack_into('<I', header, 36, 4096); struct.pack_into('<I', header, 40, 2)
        self.assertEqual(m.recovery_header_check(header, 100663296)['kernel_bytes'], 8388608)
    def test_bad_recovery_layout_is_rejected(self):
        header = bytearray(4096); header[:8] = b'ANDROID!'
        struct.pack_into('<I', header, 8, 8388608); struct.pack_into('<I', header, 36, 3000)
        with self.assertRaisesRegex(RuntimeError, 'Unrecognized recovery'):
            m.recovery_header_check(header, 100663296)

class WorkflowIntegration(unittest.TestCase):
    def test_prepare_start_restore_report_without_real_device(self):
        if not os.environ.get('KNOWN_BOOT_IMAGE'):
            self.skipTest('Private reference boot image not supplied')
        reference = Path(os.environ['KNOWN_BOOT_IMAGE'])
        class SimulatedDevice:
            path = Path('simulated-boot')
            def __init__(self): self.content_path = reference; self.writes = []
            def digest(self): return m.digest_file(self.content_path)
            def copy_to(self, path): shutil.copyfile(self.content_path, path)
            def write(self, path): self.writes.append(str(path)); self.content_path = Path(path)
        device = SimulatedDevice()
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); shared = root/'shared'; state = root/'private-state.json'
            with mock.patch.object(m, 'SHARED', shared), mock.patch.object(m, 'STATE', state), \
                 mock.patch.object(m, 'check_android_device', return_value={'model':'simulated DBY-W09'}), \
                 mock.patch.object(m, 'check_recovery_independence', return_value={'kernel_bytes':8388608,'simulated':True}), \
                 mock.patch.object(m, 'BootDevice', return_value=device), \
                 mock.patch.object(m.os, 'sync'), \
                 mock.patch.object(m.subprocess, 'run') as reboot, \
                 mock.patch.object(m, 'prop', return_value='simulated'), \
                 mock.patch('builtins.input', return_value='SIMULATION ONLY: UEFI screen not observed'):
                m.prepare(); self.assertEqual(device.writes, []); reboot.assert_not_called()
                saved = json.loads(state.read_text()); original_sha = saved['original_boot_sha256']
                self.assertEqual(m.digest_file(shared/'UEFI-TEST-BOOT.img'), m.PADDED_SHA)
                m.start(True)
                self.assertEqual(device.digest(), m.PADDED_SHA)
                reboot.assert_called_once_with(['/system/bin/reboot'], check=True)
                with self.assertRaisesRegex(RuntimeError, 'no longer the original'):
                    m.prepare()
                self.assertEqual(m.digest_file(shared/'ANDROID-BOOT-BACKUP.img'), original_sha)
                m.restore(); self.assertEqual(device.digest(), original_sha)
                m.report()
                report = next(shared.glob('UEFI-report-*.tar.gz'))
                self.assertEqual(report.stat().st_mode & 0o777, 0o644)
                with tarfile.open(report) as archive:
                    self.assertEqual(set(archive.getnames()), {'prepare-state.json','start-state.json','runtime-report.json'})
                    self.assertLess(sum(x.size for x in archive.getmembers()), 65536)
                    runtime = json.load(archive.extractfile('runtime-report.json'))
                    self.assertTrue(runtime['android_boot_restored'])
                    self.assertFalse(runtime['uefi_logs_automatically_captured'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
