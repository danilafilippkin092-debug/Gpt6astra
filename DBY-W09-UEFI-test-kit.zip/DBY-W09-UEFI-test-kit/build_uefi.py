#!/usr/bin/env python3
"""Rebuild a pinned, unvalidated DBY-W09 UEFI research candidate on Linux."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

UPSTREAM = "https://github.com/WQSQW/uefi-dby_w09.git"
REVISION = "423e222159dfa159d788769554007455d34e6193"


def run(args, cwd=None):
    subprocess.run([str(a) for a in args], cwd=cwd, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True, help="New empty build directory; needs 6+ GiB")
    args = parser.parse_args()
    missing = [x for x in ("git", "make", "gcc", "g++", "clang", "llvm-objcopy", "lld-link") if not shutil.which(x)]
    if missing:
        parser.error("Install host build tools first: " + ", ".join(missing) + ". See README-RU.md.")
    work = args.work.resolve()
    if work.exists():
        parser.error("--work must not exist; existing sources/builds are never overwritten.")
    work.mkdir(parents=True)
    source = work / "source"
    run(["git", "init", source])
    run(["git", "remote", "add", "origin", UPSTREAM], source)
    run(["git", "fetch", "--depth", "1", "origin", REVISION], source)
    run(["git", "checkout", "--detach", "FETCH_HEAD"], source)
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
    if actual != REVISION:
        raise RuntimeError("Source pin mismatch")
    run(["git", "submodule", "update", "--init", "--recursive"], source)
    venv = work / "venv"
    run([sys.executable, "-m", "venv", venv])
    python = venv / "bin" / "python"
    lock = Path(__file__).with_name("build-requirements.lock.txt")
    run([python, "-m", "pip", "install", "-r", lock])
    # Any reviewed build-only fixes are retained as a separate patch, never hidden.
    patch = Path(__file__).with_name("build-fixes.patch")
    if patch.is_file() and patch.stat().st_size:
        run(["git", "apply", "--check", patch], source)
        run(["git", "apply", patch], source)
    log = work / "build.log"
    with log.open("xb") as out:
        result = subprocess.run([python, "build_uefi.py", "-d", "dby_w09", "-r", "DEBUG"], cwd=source, stdout=out, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f"UEFI build failed ({result.returncode}); see {log}. No flash action occurred.")
    image = source / "Mu-dby_w09.img"
    if not image.is_file():
        raise SystemExit("Build returned success without an image; no artifact accepted.")
    run([sys.executable, Path(__file__).with_name("inspect_image.py"), image, "--json"])
    record = {"repository": UPSTREAM, "revision": REVISION, "mode": "DEBUG", "image": str(image),
              "sha256": hashlib.sha256(image.read_bytes()).hexdigest(), "size": image.stat().st_size,
              "hardware_tested": False, "windows_boot_tested": False, "flash_permitted_by_this_tool": False}
    (work / "build-record.json").write_text(json.dumps(record, indent=2) + "\n")
    print(f"Experimental UEFI candidate only: {image}. Hardware/Windows compatibility is unverified.")


if __name__ == "__main__":
    main()
