# Sources and provenance

The firmware is built from WQSQW/uefi-dby_w09 at commit 423e222159dfa159d788769554007455d34e6193. The original top-level license is retained in LICENSE-UPSTREAM.txt. Upstream file-specific licenses and proprietary firmware binary provenance remain applicable; no additional rights to vendor firmware are asserted by this package.

The build uses Microsoft Project Mu, TianoCore/EDK II, OpenSSL and the other commit-pinned dependencies listed in logs/submodules.lock.txt. Consult their original repositories and source-file license notices for their licenses. The full source is obtainable through the pinned build wrapper; no new Windows or Huawei proprietary firmware download is performed by the capture tool.

Android Platform Tools are not redistributed in this archive. bootstrap_adb.py downloads an exact pinned official Google archive from dl.google.com. Platform Tools usage is subject to the applicable Android SDK license and its included NOTICE/license materials, which the downloader retains. Download metadata and hashes are in platform-tools.lock.json. Official documentation: https://developer.android.com/tools/releases/platform-tools .

The supplied diagnostic scripts and tests were created for this task. Their tests use synthetic data; the package does not contain any user's tablet dumps, identifiers or personal data.
