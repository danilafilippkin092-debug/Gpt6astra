# Independent kit review

Reviewed `capture.py`, `inspect_image.py`, `bootstrap_adb.py`, `build_uefi.py`, Windows launcher and tests. Review is against the versions present at 21:27 UTC on 2026-11-12; authors may have fixed these findings subsequently. No agent-owned implementation files were changed by this reviewer.

## Findings requiring fixes

1. **Windows inventory parsing rejects every valid directory.** `capture.py` uses `str(Path(alias).parent)` for Android `/dev/block/by-name` paths, and compares it with POSIX strings. WindowsPath renders parent as `\\dev\\block\\by-name`, so Windows capture stops at inventory. Demonstrated using `PureWindowsPath('/dev/block/by-name/boot')`. Use `PurePosixPath` for remote Android paths; retain `Path` for host local files.

2. **Windows launcher version check contains invalid Python.** `RUN-CAPTURE.cmd` has `sys.version_info ^>= (3,11)` inside the double-quoted `-c` argument. CMD leaves caret literal within double quotes, and `^>=` is not Python syntax. Plain `>=` is already protected by the quoted argument. This was identified by CMD/Python semantics; an actual Windows host was not available to execute the launcher.

3. **Conflicting by-name directories can overwrite an already verified image and mark capture complete.** If `/dev/block/by-name/boot` points at one canonical partition while `/dev/block/bootdevice/by-name/boot` points at another, grouping by canonical creates two selected items named `boot`. Both write `partitions/boot.img`. POSIX `Path.rename` overwrites the first final file. Reproduced with the supplied FakeADB plus a fourth data partition: `capture()` returned `complete=True` with duplicate file paths, and only subsequent `verify()` detected overwritten contents. Reject conflicting partition-name mappings or local destination name collisions during preflight, and prevent replacing existing final images. This does not write the tablet, but corrupts the acquisition set and mislabels its manifest.

## Checks that look sound within stated scope

- No flash, erase, reboot, unlock or root-install operation exists in these scripts. `su -c` is used only for read commands after exact DBY-W09 model matching.
- Passing the entire remote command as one `exec-out` argument, then using POSIX `shlex.quote` on the Android `su -c` argument, is appropriate even for a Windows host; host shell execution is disabled.
- Binary streaming caps bytes, uses a timeout, preserves raw bytes, and never calls PowerShell text redirection.
- Partition verification compares before/after remote SHA-256 and complete local length/hash. Partial transfer, changing source hash and nonmatching local data cannot become verified partitions in normal unambiguous inventory.
- ZIP downloads are size/hash pinned before extraction, expansion is capped, path traversal checks exist, extraction is staged and avoids replacing existing tools.
- The image parser bounds header fields/sections and memory use; it explicitly states structural-only scope. It does not validate board compatibility, AVB, UEFI firmware semantics or DT node/overlay correctness, and does not claim to.
- Build accepts only a successful subprocess, expected output file and successful structural inspection; record explicitly says hardware and Windows boot untested.

## Remaining test limits

Release disposition: all three findings above were fixed before packaging. Android paths now use PurePosixPath, the launcher has plain >=, conflicting partition-name mappings are rejected during preflight, and final files are published with exclusive creation. Regression tests were added for remote path semantics, conflicting names and no-overwrite behavior. Final suite: 56 tests passed.

No real tablet, actual Windows `cmd.exe`, USB transport or EDL device was available for this review. Offline fixtures establish control flow and file integrity behavior, not DBY hardware compatibility or Windows execution.
