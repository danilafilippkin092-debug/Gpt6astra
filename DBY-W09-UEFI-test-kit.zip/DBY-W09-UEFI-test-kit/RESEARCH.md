# DBY-W09 independent source audit (2026-11-13 MSK)

## Findings

1. `edk2-porting/edk2-msm` master SHA `e1952621f419f8db60ed28271264e1b5184c571d` has SM8250 targets (Lenovo, OnePlus, Qualcomm, Samsung, Xiaomi), but no Huawei/DBY paths in a complete recursive Git tree. This is an absence in the checked tree, not proof that no private port exists.
2. `WQSQW/uefi-dby_w09` main SHA `423e222159dfa159d788769554007455d34e6193` has concrete `Platforms/Huawei/dby09Pkg` and `dby_w09Pkg`, boot configs, DTBs, vendor DXE binary directories, ACPI. It is a Mu-Silicium fork with UniXNU/Darwin research integration.
3. Its `Status.md` contains no Huawei/DBY entry and the releases endpoint returned an empty list. There is no demonstrated Windows boot in the inspected primary source material.
4. `dby_w09.dsc` explicitly says it is derived from Lenovo Y700 `9707fPkg`, uses SM8250 (`SOC_TYPE=0`), 1600x2560 SimpleFb, vendor package from that template. Current DSC includes `UniXNU` application, `UniXNUDxe` and `DarwinBoot`.
5. Firmware provenance comparison using Git blob identities: 280 of 281 `Binaries/dby_w09` files are identical to their `Binaries/9707f` counterparts; only `QcomPkg/Drivers/UsbConfigDxe/UsbConfigDxe.inf` differs. All 282 `Binaries/dby09` files are identical to `Binaries/9707f`. Directory names must not be interpreted as proof of extraction from DBY-W09 stock firmware.
6. `Silicium-ACPI/Platforms/Huawei/{dby09,dby_w09}/DSDT.aml` and `Silicium-ACPI/Platforms/Lenovo/9707f/DSDT.aml` are identical Git blobs `e058c4283bc1fe282b696856a497ff79cc7e92b7`, 5194 bytes. There is no board-specific Windows DSDT in those paths.
7. `MemoryMapLib.c` says it uses OnePlus instantnoodlep memory regions and claims DBY hardware testing for display/UFS. The final RAM region is `0xD0000000 + 0x130000000 = 0x200000000`, which is consistent with 6GiB DRAM starting at physical 0x80000000; it is not by itself proof of an invalid map. Some comments are confused about physical bounds and still ask for hardware evidence. Do not call this map verified for the user's unit or assume all DBY revisions match; a physical RAM/reservation dump remains required.
8. Boot config uses raw BootShim+FD, header v2, 4096-page layout, zero base, kernel offset 0x8000, DTB rootparam symbol for Huawei overlay. Upstream commit e4b0a14 describes fixing earlier gzip/no-DTB/bad-layout failures, but reports only packaging checks with an existing FD, not Windows execution.
9. Recent commits describe reaching Silicium/UniXNU menu, framebuffer logs, and a USB *device* debug console. This is author's hardware report, not an independently reproduced result. USB host boot from flash drive was explicitly reported never working in commit da180020.
10. Bootloader unlock support is not categorically absent in 2026. `run2000s/MatePad11_Tool_Kit_GUI` explicitly supports DBY-W09, offers EDL backup/unlock and says HarmonyOS 4 needs engineering cable/test point or downgrade. It omits proprietary `Huawei865870_devprg.elf` and unlocked ABL from source. This is an unverified community procedure, not official Huawei support, and is not a basis to silently flash ABL.

## Primary source URLs

- https://github.com/edk2-porting/edk2-msm/tree/e1952621f419f8db60ed28271264e1b5184c571d/Platform
- https://github.com/WQSQW/uefi-dby_w09/tree/423e222159dfa159d788769554007455d34e6193/Platforms/Huawei
- https://github.com/WQSQW/uefi-dby_w09/blob/423e222159dfa159d788769554007455d34e6193/Platforms/Huawei/dby_w09Pkg/Library/MemoryMapLib/MemoryMapLib.c
- https://github.com/WQSQW/uefi-dby_w09/blob/423e222159dfa159d788769554007455d34e6193/Platforms/Huawei/dby_w09Pkg/dby_w09.dsc
- https://github.com/WQSQW/uefi-dby_w09/tree/423e222159dfa159d788769554007455d34e6193/Silicium-ACPI/Platforms/Huawei
- https://github.com/WQSQW/uefi-dby_w09/commit/e4b0a14a3997c95cfb0fec208e493bb3db2390f1
- https://github.com/WQSQW/uefi-dby_w09/commit/da18002011859be1d8eb345bd0785d2307855d9b
- https://github.com/WQSQW/uefi-dby_w09/issues/3
- https://github.com/WQSQW/uefi-dby_w09/issues/5
- https://github.com/run2000s/MatePad11_Tool_Kit_GUI/blob/main/README.md
- https://github.com/pallefar/matepad-11-companion/blob/main/README.md (companion is a Windows *host* toolkit, not Windows-on-tablet; states no physical-device test)

## Implication for deliverable

A reproducible UEFI bring-up image may be buildable from the WQSQW fork with missing dependencies fixed. It must be labeled experimental and untested on the user's tablet. A generic automatic boot->UEFI converter cannot infer memory map, ACPI, GPIO or Windows drivers from the boot partition. Any backup tool must distinguish root/EDL capability from generic ADB or fastboot, and may not claim successful raw backup without verified complete reads. No mass replacement of bootloader/firmware partitions is justified by these sources.
