@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ launcher py was not found. Install Python from python.org.
  pause
  exit /b 1
)
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
  echo Python 3.11 or newer is required.
  pause
  exit /b 1
)
py -3 bootstrap_adb.py
if errorlevel 1 (
  echo Official Android tools could not be downloaded or verified.
  pause
  exit /b 1
)
set "DBY_ADB=%~dp0tools\platform-tools\adb.exe"
set "DBY_CAPTURE=%~dp0captures\backup-%RANDOM%-%RANDOM%"
echo Reads selected boot and firmware partitions. Does not flash, unlock or reboot.
echo Requires an authorized DBY-W09 with root already available.
py -3 capture.py capture --adb "%DBY_ADB%" --output "%DBY_CAPTURE%"
set "DBY_RESULT=%ERRORLEVEL%"
if not "%DBY_RESULT%"=="0" (
  echo Capture failed or incomplete. Keep manifest.json for diagnosis.
) else (
  echo Verified selected partition capture saved in %DBY_CAPTURE%.
  echo This is not a full recovery backup and does not establish UEFI compatibility.
)
pause
exit /b %DBY_RESULT%
