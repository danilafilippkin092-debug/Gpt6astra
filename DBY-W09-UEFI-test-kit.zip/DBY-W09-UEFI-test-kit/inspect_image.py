#!/usr/bin/env python3
"""Read-only structural inspection of Android boot images (header versions 0-4).

This does not establish board compatibility, AVB validity, or bootability. Huawei
split ``kernel`` images and vendor_boot images are deliberately not guessed.
Only fixed-size headers and bounded 1 MiB chunks are held in memory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from typing import BinaryIO


class ImageError(ValueError):
    """The file is unsupported or structurally inconsistent."""


HEADER_SIZES = {0: 1632, 1: 1648, 2: 1660, 3: 1580, 4: 1584}


def _read(f: BinaryIO, offset: int, size: int) -> bytes:
    f.seek(offset)
    data = f.read(size)
    if len(data) != size:
        raise ImageError(f"Truncated data at offset {offset}: need {size} bytes")
    return data


def _uint(data: bytes, offset: int, size: int = 4, endian: str = "little") -> int:
    return int.from_bytes(data[offset:offset + size], endian)


def _align(value: int, page: int) -> int:
    return (value + page - 1) // page * page


def _hash(f: BinaryIO, offset: int, size: int) -> str:
    f.seek(offset)
    digest = hashlib.sha256()
    remaining = size
    while remaining:
        chunk = f.read(min(remaining, 1024 * 1024))
        if not chunk:
            raise ImageError("Image changed or was truncated during hashing")
        remaining -= len(chunk)
        digest.update(chunk)
    return digest.hexdigest()


def _fdt(f: BinaryIO, offset: int, section_size: int) -> dict:
    if section_size < 40:
        raise ImageError("DTB section is too short for an FDT header")
    header = _read(f, offset, 40)
    fields = struct.unpack(">10I", header)
    magic, total, structure, strings, reserve, version, compatible, _, strings_size, struct_size = fields
    if magic != 0xD00DFEED:
        raise ImageError("DTB section does not start with FDT magic")
    if total < 40 or total > section_size:
        raise ImageError("FDT totalsize exceeds its DTB section or is too small")
    if version < 17 or compatible > version or compatible > 17:
        raise ImageError("Unsupported or inconsistent FDT version")
    if reserve < 40 or reserve % 8 or reserve + 16 > total:
        raise ImageError("Invalid FDT reservation-map offset")
    if structure < 40 or structure % 4 or structure + struct_size > total:
        raise ImageError("FDT structure block exceeds totalsize or is misaligned")
    if strings < 40 or strings + strings_size > total:
        raise ImageError("FDT strings block exceeds totalsize")
    if struct_size and strings_size and max(structure, strings) < min(structure + struct_size, strings + strings_size):
        raise ImageError("FDT structure and strings blocks overlap")
    return {
        "version": version,
        "totalsize": total,
        "first_tree_only": True,
        "section_extra_bytes": section_size - total,
        "scope": "FDT header bounds only; nodes and overlays are not validated",
    }


def inspect(path: str | Path) -> dict:
    """Inspect *path*, returning JSON-ready structural metadata, or ImageError.

    No claim about whether the payload can run on DBY-W09 is made. Extra trailing
    bytes are reported, since a partition dump may contain padding or AVB data.
    """
    path = Path(path)
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            if size < 44:
                raise ImageError("Image is too short for an Android boot header")
            prefix = _read(f, 0, 44)
            if prefix[:8] != b"ANDROID!":
                raise ImageError("Unsupported image magic; expected ANDROID! (Huawei split kernel and vendor_boot formats are not inferred)")
            version = _uint(prefix, 40)
            if version not in HEADER_SIZES:
                raise ImageError(f"Unsupported Android boot header version: {version}")
            header = _read(f, 0, HEADER_SIZES[version])
            page = _uint(header, 36) if version <= 2 else 4096
            if page < 2048 or page > 65536 or page & (page - 1):
                raise ImageError(f"Invalid page size: {page}")
            header_size = 1632 if version == 0 else _uint(header, 1644 if version <= 2 else 20)
            if header_size < HEADER_SIZES[version] or header_size > page:
                raise ImageError(f"Invalid header_size {header_size} for version {version} and page size {page}")
            if size < page:
                raise ImageError("Truncated header page")
            result = {
                "format": "android_boot",
                "header_version": version,
                "header_size": header_size,
                "page_size": page,
                "file_size": size,
                "sections": {},
                "validation": "structural_only",
                "hardware_compatibility": "NOT_VERIFIED",
                "signature_authenticity": "NOT_VERIFIED",
            }
            sections = result["sections"]
            cursor = page

            def add(name: str, length: int, explicit_offset: int | None = None) -> None:
                nonlocal cursor
                offset = cursor if explicit_offset is None else explicit_offset
                if offset != cursor:
                    raise ImageError(f"Inconsistent {name} offset {offset}; expected {cursor}")
                if length > size - offset:
                    raise ImageError(f"Truncated {name} section: {length} bytes at offset {offset}")
                sections[name] = {"offset": offset, "size": length}
                cursor = offset + _align(length, page)

            if version <= 2:
                result["load_addresses"] = {
                    "kernel": _uint(header, 12),
                    "ramdisk": _uint(header, 20),
                    "second": _uint(header, 28),
                    "tags": _uint(header, 32),
                }
                add("kernel", _uint(header, 8))
                add("ramdisk", _uint(header, 16))
                add("second", _uint(header, 24))
                if version >= 1:
                    dtbo_size = _uint(header, 1632)
                    dtbo_offset = _uint(header, 1636, 8)
                    if dtbo_size:
                        add("recovery_dtbo", dtbo_size, dtbo_offset)
                    elif dtbo_offset != 0:
                        raise ImageError("Nonzero recovery_dtbo offset with zero section size")
                if version == 2:
                    dtb_size = _uint(header, 1648)
                    result["load_addresses"]["dtb"] = _uint(header, 1652, 8)
                    add("dtb", dtb_size)
                    if dtb_size:
                        result["fdt"] = _fdt(f, sections["dtb"]["offset"], dtb_size)
            else:
                if any(header[24:40]):
                    raise ImageError("Reserved v3/v4 header fields must be zero")
                add("kernel", _uint(header, 8))
                add("ramdisk", _uint(header, 12))
                if version == 4:
                    add("boot_signature", _uint(header, 1580))

            # Full final-page padding is required by the Android boot image
            # layout, including its final nonempty section.
            if cursor > size:
                raise ImageError("Truncated final section page padding")
            kernel = sections["kernel"]
            kernel["sha256"] = _hash(f, kernel["offset"], kernel["size"])
            kernel["arm64_image_magic"] = (
                kernel["size"] >= 60
                and _read(f, kernel["offset"] + 56, 4) == b"ARM\x64"
            )
            result["layout_end"] = cursor
            result["trailing_bytes"] = size - cursor
            result["sha256"] = _hash(f, 0, size)
            return result
    except OSError as exc:
        raise ImageError(f"Cannot read image: {exc}") from exc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument("--json", action="store_true", help="Print JSON metadata")
    args = parser.parse_args(argv)
    try:
        report = inspect(args.image)
    except ImageError as exc:
        print(f"Image inspection failed: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(f"Android boot v{report['header_version']}, {report['file_size']} bytes; structural checks passed.")
        print("Hardware compatibility and signature authenticity: NOT VERIFIED.")
        for name, section in report["sections"].items():
            print(f"  {name}: offset={section['offset']}, size={section['size']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
