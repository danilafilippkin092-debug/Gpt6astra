#!/usr/bin/env python3
"""DBY-W09 read-only, owner-operated acquisition. Python 3.11+, stdlib only.

The only tablet commands are devices, getprop, id, readlink, test, blockdev,
sha256sum, cat and a read-only directory inventory. No flashing or rebooting.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading

VERSION = "0.1.0"
MAX_PARTITION = 256 * 1024**2
MAX_TOTAL = 2 * 1024**3
RESERVE = 288 * 1024**2
MAX_METADATA = 16 * 1024**2
ALLOWLIST = frozenset(
    n + suffix
    for n in ("boot", "kernel", "dtb", "dtbo", "vbmeta", "vbmeta_system",
              "vbmeta_vendor", "recovery", "recovery_ramdisk", "recovery_vbmeta",
              "recovery_vendor", "vendor_boot", "init_boot", "xbl", "xbl_config", "abl")
    for suffix in ("", "_a", "_b")
)
PROPERTIES = (
    "ro.product.model", "ro.product.vendor.model", "ro.product.device",
    "ro.product.board", "ro.board.platform", "ro.hardware", "ro.soc.model",
    "ro.build.display.id", "ro.build.fingerprint", "ro.build.version.release",
    "ro.build.version.sdk", "ro.build.version.security_patch", "ro.boot.slot_suffix",
    "ro.boot.flash.locked", "ro.boot.verifiedbootstate", "ro.boot.vbmeta.device_state",
)
INVENTORY = (
    'for d in /dev/block/by-name /dev/block/bootdevice/by-name; do '
    '[ -d "$d" ] || continue; for p in "$d"/*; do '
    '[ -b "$p" ] || continue; printf "%s\\t" "$p"; readlink -f "$p"; '
    'done; done'
)
HEX = re.compile(r"^[0-9a-f]{64}$")
BLOCK_PATH = re.compile(r"^/dev/block/[A-Za-z0-9_./-]+$")


class CaptureError(RuntimeError):
    pass


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            h.update(block)
    return h.hexdigest()


def safe_block(path: str) -> bool:
    return bool(BLOCK_PATH.fullmatch(path)) and ".." not in path.split("/")


def redact(text: str, serial: str = "") -> str:
    if serial:
        text = text.replace(serial, "[REDACTED_SERIAL]")
    return re.sub(r"(?i)((?:androidboot\.)?(?:serialno|serial|imei|meid|macaddr|btaddr)=)\S+",
                  r"\1[REDACTED]", text)


class ADB:
    def __init__(self, executable: str, serial: str | None = None):
        self.executable = executable
        self.serial = serial
        self.use_su = False

    def run(self, args: list[str], *, timeout: int = 30) -> bytes:
        try:
            result = subprocess.run([self.executable] + args, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, timeout=timeout, check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise CaptureError(f"ADB command unavailable or timed out ({type(exc).__name__}).") from exc
        if result.returncode:
            # Do not log arbitrary adb stderr, which can contain identifiers.
            raise CaptureError(f"ADB command failed (exit {result.returncode}).")
        return result.stdout

    def select(self) -> None:
        lines = self.run(["devices"]).decode("utf-8", "replace").splitlines()
        devices = []
        for line in lines:
            fields = line.split()
            if not fields or line.startswith("List of devices") or line.startswith("*"):
                continue
            if len(fields) >= 2:
                devices.append((fields[0], fields[1]))
        if self.serial:
            matches = [(s, state) for s, state in devices if s == self.serial]
            if len(matches) != 1 or matches[0][1] != "device":
                raise CaptureError("Selected tablet is absent, unauthorized or offline.")
        else:
            if len(devices) != 1 or devices[0][1] != "device":
                raise CaptureError("Connect exactly one authorized tablet, or use --serial.")
            self.serial = devices[0][0]

    def command(self, script: str, *, root: bool = False) -> list[str]:
        if not self.serial:
            raise CaptureError("No selected ADB device.")
        if root and self.use_su:
            script = "su -c " + shlex.quote(script)
        return ["-s", self.serial, "exec-out", script]

    def text(self, script: str, *, root: bool = False) -> str:
        return self.run(self.command(script, root=root)).decode("utf-8", "replace").strip()

    def require_root(self) -> None:
        if self.text("id -u") == "0":
            return
        self.use_su = True
        if self.text("id -u", root=True) != "0":
            raise CaptureError("Root is unavailable. No block-device reads were attempted.")

    def stream(self, script: str, destination: Path, limit: int, *, root: bool = True,
               timeout: int = 300) -> int:
        """Binary-safe bounded copy into a new local file; kill hung host adb."""
        command = [self.executable] + self.command(script, root=root)
        timed_out = threading.Event()
        with destination.open("xb") as output, tempfile.TemporaryFile() as errors:
            try:
                proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors)
            except OSError as exc:
                raise CaptureError("Cannot start ADB transfer.") from exc
            def expire():
                timed_out.set()
                try:
                    proc.kill()
                except OSError:
                    pass
            watchdog = threading.Timer(timeout, expire)
            watchdog.daemon = True
            watchdog.start()
            length = 0
            try:
                assert proc.stdout is not None
                while True:
                    block = proc.stdout.read(min(1024**2, limit - length + 1))
                    if not block:
                        break
                    length += len(block)
                    if length > limit:
                        raise CaptureError("Transfer exceeded declared size or allowed limit.")
                    output.write(block)
                proc.wait(timeout=10)
                if timed_out.is_set() or proc.returncode:
                    raise CaptureError("ADB transfer failed or timed out.")
                output.flush()
                os.fsync(output.fileno())
            finally:
                watchdog.cancel()
                if proc.poll() is None:
                    proc.kill()
                proc.wait()
                if proc.stdout is not None:
                    proc.stdout.close()
        return length


def parse_inventory(text: str) -> tuple[list[dict], list[dict]]:
    groups: dict[str, list[str]] = {}
    inventory = []
    name_targets: dict[str, str] = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        fields = line.split("\t")
        if len(fields) != 2:
            raise CaptureError("Malformed block inventory; refusing to guess partition paths.")
        alias, canonical = fields
        if not safe_block(alias) or not safe_block(canonical):
            raise CaptureError("Unexpected path in block inventory.")
        if str(PurePosixPath(alias).parent) not in ("/dev/block/by-name", "/dev/block/bootdevice/by-name"):
            raise CaptureError("Unexpected by-name directory.")
        name = PurePosixPath(alias).name
        inventory.append({"name": name, "path": alias, "canonical": canonical,
                          "selected": name in ALLOWLIST})
        # No other names are ever used as inputs to partition reads.
        if name in ALLOWLIST:
            previous = name_targets.setdefault(name, canonical)
            if previous != canonical:
                raise CaptureError("Same partition name resolves to different block devices: " + name)
            groups.setdefault(canonical, []).append(alias)
    selected = []
    for canonical, aliases in sorted(groups.items()):
        aliases = sorted(set(aliases))
        selected.append({"canonical": canonical, "aliases": aliases,
                         "name": PurePosixPath(aliases[0]).name})
    return inventory, selected


def remote_hash(adb: ADB, path: str) -> str:
    if not safe_block(path):
        raise CaptureError("Unsafe block-device path.")
    value = adb.text("sha256sum " + shlex.quote(path), root=True).split()
    if not value or not HEX.fullmatch(value[0]):
        raise CaptureError("Tablet did not provide a SHA-256 digest.")
    return value[0]



def publish_file(source: Path, destination: Path) -> None:
    """Publish verified bytes without replacing any existing destination.

    Exclusive creation works on Windows and POSIX, including volumes without
    hard-link support. A failed copy keeps the original .partial and removes
    only the new file this invocation created.
    """
    created = False
    try:
        with source.open("rb") as incoming, destination.open("xb") as outgoing:
            created = True
            shutil.copyfileobj(incoming, outgoing, length=1024**2)
            outgoing.flush()
            os.fsync(outgoing.fileno())
        if source.stat().st_size != destination.stat().st_size or digest(source) != digest(destination):
            raise CaptureError("Verified-file publication changed byte count or SHA-256.")
        source.unlink()
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
        raise


def save_manifest(directory: Path, manifest: dict) -> None:
    temporary = directory / "manifest.json.partial"
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(directory / "manifest.json")


def record_file(manifest: dict, directory: Path, path: Path, **extra) -> dict:
    entry = {"path": path.relative_to(directory).as_posix(), "size": path.stat().st_size,
             "sha256": digest(path), **extra}
    manifest["files"].append(entry)
    return entry


def capture(output: Path, adb: ADB) -> dict:
    # An existing directory is deliberately rejected, including one from a failed run.
    output.mkdir(parents=True, exist_ok=False)
    manifest = {"schema": 1, "tool_version": VERSION,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "status": "in_progress", "complete": False,
                "scope": "selected boot/firmware partitions only; NOT a full recovery backup",
                "files": [], "partitions": [], "errors": [], "notes": []}
    save_manifest(output, manifest)
    try:
        adb.select()
        manifest["device_id_sha256"] = hashlib.sha256((adb.serial or "").encode()).hexdigest()
        model = adb.text("getprop ro.product.model")
        manifest["model"] = redact(model, adb.serial or "")
        if model.upper() != "DBY-W09":
            raise CaptureError("Model is not exactly DBY-W09. No root/block access was attempted.")
        properties = {}
        for key in PROPERTIES:
            properties[key] = redact(adb.text("getprop " + key), adb.serial or "")
        props_path = output / "properties.json"
        props_path.write_text(json.dumps(properties, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        record_file(manifest, output, props_path, kind="metadata")
        adb.require_root()
        inventory, selected = parse_inventory(adb.text(INVENTORY, root=True))
        manifest["inventory"] = inventory
        names = {i["name"] for i in inventory if i["selected"]}
        groups = {"boot_or_kernel": {n + s for n in ("boot", "kernel") for s in ("", "_a", "_b")},
                  "dtbo": {"dtbo", "dtbo_a", "dtbo_b"},
                  "vbmeta": {"vbmeta", "vbmeta_a", "vbmeta_b"}}
        manifest["critical_groups"] = {key: {"present": sorted(names & allowed), "verified": False}
                                       for key, allowed in groups.items()}
        total = 0
        for item in selected:
            path = item["canonical"]
            qpath = shlex.quote(path)
            # Check size/canonical mapping before any potentially large read.
            for alias in item["aliases"]:
                if adb.text("readlink -f " + shlex.quote(alias), root=True) != path:
                    raise CaptureError("Partition alias changed during preflight.")
            size_text = adb.text("blockdev --getsize64 " + qpath, root=True)
            if not re.fullmatch(r"[0-9]+", size_text):
                raise CaptureError("Invalid partition byte size.")
            size = int(size_text)
            if not 0 < size <= MAX_PARTITION:
                raise CaptureError(f"Partition {item['name']} exceeds the allowed size or is empty.")
            item["size"] = size
            total += size
            if total > MAX_TOTAL:
                raise CaptureError("Selected partitions exceed the 2 GiB capture cap.")
        if not selected:
            raise CaptureError("No supported boot/firmware partitions found.")
        if shutil.disk_usage(output).free < total + RESERVE:
            raise CaptureError("Insufficient disk space for selected partitions plus reserve.")
        manifest["planned_bytes"] = total
        for remote, name in (("/proc/iomem", "iomem.txt"), ("/proc/meminfo", "meminfo.txt"),
                             ("/proc/cmdline", "cmdline.txt")):
            try:
                text = redact(adb.text("cat " + remote, root=True), adb.serial or "")
                path = output / name
                path.write_text(text + "\n", encoding="utf-8")
                record_file(manifest, output, path, kind="metadata", redacted=True)
            except CaptureError:
                manifest["notes"].append(f"Optional metadata unavailable: {remote}")
        for remote, name in (("/proc/device-tree/model", "dt-model.txt"),
                             ("/proc/device-tree/compatible", "dt-compatible.txt"),
                             ("/proc/device-tree/chosen/bootargs", "dt-bootargs.txt")):
            try:
                text = redact(adb.text("cat " + remote, root=True), adb.serial or "")
                path = output / name
                path.write_text(text + "\n", encoding="utf-8")
                record_file(manifest, output, path, kind="metadata", redacted=True)
            except CaptureError:
                manifest["notes"].append(f"Optional device-tree metadata unavailable: {remote}")
        try:
            if adb.text("test -r /sys/firmware/fdt && echo readable || echo absent", root=True) == "readable":
                partial = output / "firmware.dtb.partial"
                length = adb.stream("cat /sys/firmware/fdt", partial, MAX_METADATA)
                if length < 40 or partial.read_bytes()[:4] != b"\xd0\x0d\xfe\xed":
                    raise CaptureError("Live FDT is empty or has an invalid magic.")
                final = output / "firmware.dtb"
                publish_file(partial, final)
                record_file(manifest, output, final, kind="live_fdt")
            else:
                manifest["notes"].append("Live FDT unavailable at /sys/firmware/fdt.")
        except CaptureError:
            manifest["notes"].append("Live FDT could not be captured; firmware.dtb.partial is not verified.")
        verified_names = set()
        partitions_dir = output / "partitions"
        partitions_dir.mkdir()
        for item in selected:
            entry = {**item, "verified": False}
            manifest["partitions"].append(entry)
            save_manifest(output, manifest)
            try:
                path, size = item["canonical"], item["size"]
                before = remote_hash(adb, path)
                partial = partitions_dir / (item["name"] + ".img.partial")
                length = adb.stream("cat " + shlex.quote(path), partial, size)
                after = remote_hash(adb, path)
                local = digest(partial)
                if length != size or partial.stat().st_size != size:
                    raise CaptureError("Partition byte count differs from blockdev size.")
                if not before == after == local:
                    raise CaptureError("Partition SHA-256 changed or differs from local copy.")
                final = partial.with_suffix("")
                publish_file(partial, final)
                file_entry = record_file(manifest, output, final, kind="partition",
                                         source_sha256_before=before, source_sha256_after=after,
                                         verified=True)
                entry.update({"verified": True, "file": file_entry["path"], "sha256": local})
                verified_names.update(PurePosixPath(alias).name for alias in item["aliases"])
            except CaptureError as exc:
                entry["error"] = str(exc)
                manifest["errors"].append(f"{item['name']}: {exc}")
            save_manifest(output, manifest)
        for key, allowed in groups.items():
            verified = bool(verified_names & allowed)
            manifest["critical_groups"][key]["verified"] = verified
            if not verified:
                manifest["errors"].append(f"Critical group absent or not verified: {key}")
        manifest["complete"] = not manifest["errors"] and all(p["verified"] for p in manifest["partitions"])
        manifest["status"] = "complete" if manifest["complete"] else "incomplete"
    except BaseException as exc:
        manifest["status"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "failed"
        # Exception text is controlled for expected failures; avoid leaking raw subprocess arguments.
        message = str(exc) if isinstance(exc, CaptureError) else type(exc).__name__
        manifest["errors"].append(redact(message, adb.serial or ""))
        save_manifest(output, manifest)
        raise
    save_manifest(output, manifest)
    return manifest


def verify(backup: Path) -> dict:
    if not backup.is_dir():
        raise CaptureError("Backup directory does not exist.")
    try:
        manifest = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise CaptureError("Cannot read manifest.json.") from exc
    if not isinstance(manifest, dict) or manifest.get("schema") != 1 or manifest.get("model", "").upper() != "DBY-W09":
        raise CaptureError("Unsupported or incorrect-device manifest.")
    entries = manifest.get("files")
    if not isinstance(entries, list) or not entries:
        raise CaptureError("Manifest has no captured files.")
    seen = set()
    verified_files = {}
    root = backup.resolve()
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
            raise CaptureError("Invalid file entry.")
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts or "\\" in entry["path"]:
            raise CaptureError("Unsafe manifest file path.")
        path = backup / relative
        if entry["path"] in seen or path.is_symlink() or not path.resolve().is_relative_to(root):
            raise CaptureError("Duplicate, symbolic or escaping manifest path.")
        seen.add(entry["path"])
        if not path.is_file() or path.stat().st_size != entry.get("size") or digest(path) != entry.get("sha256"):
            raise CaptureError("Captured file missing, truncated or SHA-256 mismatch: " + entry["path"])
        verified_files[entry["path"]] = entry
        if entry.get("kind") == "partition":
            if not entry.get("verified") or not entry.get("sha256") == entry.get("source_sha256_before") == entry.get("source_sha256_after"):
                raise CaptureError("Partition lacks source/local hash agreement.")
    partitions = manifest.get("partitions", [])
    if not isinstance(partitions, list) or not partitions:
        raise CaptureError("Manifest has no partition records.")
    names = set()
    for entry in partitions:
        if not isinstance(entry, dict) or not entry.get("verified") or entry.get("name") not in ALLOWLIST:
            raise CaptureError("Manifest contains an unverified or unexpected partition.")
        file = verified_files.get(entry.get("file"))
        if not file or file.get("kind") != "partition" or file.get("sha256") != entry.get("sha256") or file.get("size") != entry.get("size"):
            raise CaptureError("Partition/file records disagree.")
        aliases = entry.get("aliases", [])
        for alias in aliases:
            if not isinstance(alias, str) or not safe_block(alias) or PurePosixPath(alias).name not in ALLOWLIST:
                raise CaptureError("Invalid partition alias.")
            names.add(PurePosixPath(alias).name)
    if not names.intersection({n+s for n in ("boot", "kernel") for s in ("", "_a", "_b")}):
        raise CaptureError("No verified boot/kernel group.")
    for name in ("dtbo", "vbmeta"):
        if not names.intersection({name, name+"_a", name+"_b"}):
            raise CaptureError("No verified " + name + " group.")
    if manifest.get("status") != "complete" or manifest.get("complete") is not True or manifest.get("errors"):
        raise CaptureError("Acquisition was not complete; consult manifest errors.")
    return manifest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="action", required=True)
    collect = subs.add_parser("capture", help="Read selected partitions; never writes to tablet")
    collect.add_argument("--output", required=True, type=Path)
    collect.add_argument("--adb", default="adb", help="Official Android Platform Tools adb executable")
    collect.add_argument("--serial", help="Select a tablet when multiple ADB devices are attached")
    check = subs.add_parser("verify", help="Verify all local file sizes and SHA-256 checksums")
    check.add_argument("--backup", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        if args.action == "capture":
            manifest = capture(args.output, ADB(args.adb, args.serial))
            if not manifest["complete"]:
                print("Capture incomplete. See manifest.json; no tablet partitions were changed.", file=sys.stderr)
                return 2
            verify(args.output)
            print("Selected partition capture verified. This is NOT a full recovery backup.")
        else:
            verify(args.backup)
            print("Local captured files verified. Hardware/UEFI compatibility is not established.")
        return 0
    except KeyboardInterrupt:
        print("Interrupted. Incomplete local files are not usable as verified backups.", file=sys.stderr)
        return 130
    except (CaptureError, OSError, ValueError) as exc:
        # Avoid printing serials embedded in OS errors/path arguments.
        print("Stopped: " + (str(exc) if isinstance(exc, CaptureError) else type(exc).__name__), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
