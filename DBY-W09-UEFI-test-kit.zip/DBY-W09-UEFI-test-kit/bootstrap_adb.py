#!/usr/bin/env python3
"""Download pinned official Android tools into this directory, never system PATH."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import tempfile
import urllib.request
import zipfile


ROOT = Path(__file__).resolve().parent


def install(root=ROOT, system=None, opener=urllib.request.urlopen):
    system = system or platform.system()
    key = {"Windows": "windows", "Linux": "linux"}.get(system)
    if key is None:
        raise RuntimeError("Automatic download supports Windows/Linux x86-64 only; use your official SDK adb.")
    if platform.machine().lower() not in {"amd64", "x86_64"}:
        raise RuntimeError("Automatic download requires an x86-64 host; supply SDK adb manually.")
    spec = json.loads((root / "platform-tools.lock.json").read_text())[key]
    destination = root / "tools" / "platform-tools"
    executable = destination / ("adb.exe" if key == "windows" else "adb")
    stamp = destination / ".verified-files.json"
    if stamp.is_file():
        saved = json.loads(stamp.read_text())
        if saved.get("archive_sha256") == spec["sha256"]:
            files = saved.get("files", {})
            if files and executable.is_file() and all(
                (destination / name).is_file()
                and hashlib.sha256((destination / name).read_bytes()).hexdigest() == digest
                for name, digest in files.items()
            ):
                return executable
    if destination.exists():
        raise RuntimeError("Existing tools are not verified. Move tools/platform-tools aside and retry.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix="download-") as td:
        tmp = Path(td)
        archive = tmp / "tools.zip"
        digest = hashlib.sha256()
        count = 0
        with opener(spec["url"], timeout=60) as response, archive.open("xb") as out:
            while chunk := response.read(1024 * 1024):
                count += len(chunk)
                if count > spec["size"]:
                    raise RuntimeError("Archive larger than pinned size.")
                digest.update(chunk)
                out.write(chunk)
        if count != spec["size"] or digest.hexdigest() != spec["sha256"]:
            raise RuntimeError("Official archive checksum/size mismatch; nothing installed.")
        stage = tmp / "stage"
        files = {}
        with zipfile.ZipFile(archive) as z:
            if sum(i.file_size for i in z.infolist()) > 128 * 1024 * 1024:
                raise RuntimeError("Archive expands beyond size limit.")
            for info in z.infolist():
                name = PurePosixPath(info.filename)
                if name.is_absolute() or ".." in name.parts or not name.parts or name.parts[0] != "platform-tools" or "\\" in info.filename or ":" in info.filename:
                    raise RuntimeError("Unsafe archive member.")
                if info.is_dir():
                    continue
                relative = PurePosixPath(*name.parts[1:])
                target = stage / "platform-tools" / str(relative)
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as source, target.open("xb") as out:
                    shutil.copyfileobj(source, out)
                files[str(relative)] = hashlib.sha256(target.read_bytes()).hexdigest()
        staged = stage / "platform-tools"
        staged_executable = staged / executable.name
        if not staged_executable.is_file():
            raise RuntimeError("Archive has no adb executable.")
        if key == "linux":
            staged_executable.chmod(0o755)
        (staged / ".verified-files.json").write_text(json.dumps({"archive_sha256": spec["sha256"], "files": files}, indent=2))
        os.rename(staged, destination)
    return executable


if __name__ == "__main__":
    try:
        print(install())
    except (OSError, RuntimeError, ValueError, zipfile.BadZipFile) as error:
        raise SystemExit(f"ADB setup failed: {error}")
