import hashlib
from pathlib import Path
import struct
import tempfile
import unittest

import inspect_image


def align(n, page=4096):
    return (n + page - 1) // page * page


def fdt():
    # Header + terminated reservation map + FDT_END node (not a node parser).
    return struct.pack(">10I", 0xD00DFEED, 60, 56, 60, 40, 17, 16, 0, 0, 4) + bytes(16) + struct.pack(">I", 9)


def image(version=2, dtbo=False, signature_size=64):
    page = 4096
    header = bytearray(page)
    header[:8] = b"ANDROID!"
    struct.pack_into("<I", header, 40, version)
    kernel = bytearray(128)
    kernel[56:60] = b"ARM\x64"
    ramdisk = b"test-ramdisk\x00\r\n\xff"
    parts = [kernel, ramdisk]
    struct.pack_into("<I", header, 8, len(kernel))
    if version <= 2:
        struct.pack_into("<I", header, 16, len(ramdisk))
        struct.pack_into("<I", header, 36, page)
        struct.pack_into("<I", header, 12, 0x8000)
        if version:
            struct.pack_into("<I", header, 1644, inspect_image.HEADER_SIZES[version])
            if dtbo:
                parts.append(b"recovery-overlay")
                struct.pack_into("<IQ", header, 1632, len(parts[-1]), page * 3)
        if version == 2:
            parts.append(fdt())
            struct.pack_into("<IQ", header, 1648, len(parts[-1]), 0x1F00000)
    else:
        struct.pack_into("<I", header, 12, len(ramdisk))
        struct.pack_into("<I", header, 20, inspect_image.HEADER_SIZES[version])
        if version == 4:
            struct.pack_into("<I", header, 1580, signature_size)
            parts.append(b"S" * signature_size)
    return bytes(header) + b"".join(bytes(p) + bytes(align(len(p)) - len(p)) for p in parts)


class InspectImageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "boot.img"

    def tearDown(self):
        self.tmp.cleanup()

    def inspect(self, data):
        self.path.write_bytes(data)
        return inspect_image.inspect(self.path)

    def test_all_versions(self):
        for version in range(5):
            with self.subTest(version=version):
                report = self.inspect(image(version))
                self.assertEqual(report["header_version"], version)
                self.assertEqual(report["hardware_compatibility"], "NOT_VERIFIED")
                self.assertTrue(report["sections"]["kernel"]["arm64_image_magic"])

    def test_binary_sha256(self):
        data = image()
        report = self.inspect(data)
        self.assertEqual(report["sha256"], hashlib.sha256(data).hexdigest())
        self.assertEqual(report["sections"]["kernel"]["sha256"], hashlib.sha256(data[4096:4224]).hexdigest())

    def test_v2_recovery_dtbo(self):
        report = self.inspect(image(2, dtbo=True))
        self.assertEqual(report["sections"]["recovery_dtbo"]["offset"], 12288)
        self.assertEqual(report["sections"]["dtb"]["offset"], 16384)
        self.assertEqual(report["fdt"]["totalsize"], 60)

    def test_v4_signature(self):
        report = self.inspect(image(4, signature_size=5000))
        self.assertEqual(report["sections"]["boot_signature"]["size"], 5000)
        self.assertEqual(report["layout_end"], 20480)

    def test_v4_zero_signature(self):
        report = self.inspect(image(4, signature_size=0))
        self.assertEqual(report["sections"]["boot_signature"]["size"], 0)

    def test_trailing_partition_padding(self):
        report = self.inspect(image() + b"AVBf" + bytes(1020))
        self.assertEqual(report["trailing_bytes"], 1024)

    def test_bad_magic(self):
        for magic in (b"VNDRBOOT", b"KERNEL!!", bytes(8)):
            with self.subTest(magic=magic), self.assertRaises(inspect_image.ImageError):
                self.inspect(magic + image()[8:])

    def test_bad_version(self):
        data = bytearray(image())
        struct.pack_into("<I", data, 40, 99)
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_bad_page(self):
        for page in (0, 1024, 4097, 131072, 0xFFFFFFFF):
            data = bytearray(image())
            struct.pack_into("<I", data, 36, page)
            with self.subTest(page=page), self.assertRaises(inspect_image.ImageError):
                self.inspect(data)

    def test_bad_header_size(self):
        for version in (1, 2, 3, 4):
            for size in (0, inspect_image.HEADER_SIZES[version] - 1, 4097, 0xFFFFFFFF):
                data = bytearray(image(version))
                struct.pack_into("<I", data, 1644 if version <= 2 else 20, size)
                with self.subTest(version=version, size=size), self.assertRaises(inspect_image.ImageError):
                    self.inspect(data)

    def test_truncations(self):
        data = image()
        for length in (0, 7, 43, 1631, 1659, 4095, 4223, 8193, len(data) - 1):
            with self.subTest(length=length), self.assertRaises(inspect_image.ImageError):
                self.inspect(data[:length])

    def test_huge_kernel_size(self):
        data = bytearray(image())
        struct.pack_into("<I", data, 8, 0xFFFFFFFF)
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_inconsistent_dtbo_offset(self):
        for offset in (0, 4096, 12289, 16384, 2**63):
            data = bytearray(image(2, dtbo=True))
            struct.pack_into("<Q", data, 1636, offset)
            with self.subTest(offset=offset), self.assertRaises(inspect_image.ImageError):
                self.inspect(data)

    def test_empty_dtbo_nonzero_offset(self):
        data = bytearray(image())
        struct.pack_into("<Q", data, 1636, 12288)
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_dtb_out_of_file(self):
        data = bytearray(image())
        struct.pack_into("<I", data, 1648, 0xFFFFFFFF)
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_bad_fdt_magic(self):
        data = bytearray(image())
        data[12288:12292] = b"BAD!"
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_fdt_header_bounds(self):
        for offset, value in ((4, 0xFFFFFFFF), (8, 0xFFFFFFFF), (12, 0xFFFFFFFF), (16, 41), (20, 1), (24, 99), (36, 0xFFFFFFFF)):
            data = bytearray(image())
            struct.pack_into(">I", data, 12288 + offset, value)
            with self.subTest(offset=offset), self.assertRaises(inspect_image.ImageError):
                self.inspect(data)

    def test_v3_reserved(self):
        data = bytearray(image(3))
        data[24] = 1
        with self.assertRaises(inspect_image.ImageError):
            self.inspect(data)

    def test_missing_file(self):
        with self.assertRaises(inspect_image.ImageError):
            inspect_image.inspect(Path(self.tmp.name) / "absent.img")


if __name__ == "__main__":
    unittest.main()
