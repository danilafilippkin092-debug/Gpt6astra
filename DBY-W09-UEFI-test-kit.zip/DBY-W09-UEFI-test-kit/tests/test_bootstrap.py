import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from bootstrap_adb import install


class BootstrapTests(unittest.TestCase):
    def archive(self, name="platform-tools/adb.exe"):
        content = io.BytesIO()
        with zipfile.ZipFile(content, "w") as z:
            z.writestr(name, b"binary-adb-fixture\x00\r\n")
            z.writestr("platform-tools/AdbWinApi.dll", b"fixture-dll")
        return content.getvalue()

    def setup_root(self, root, data, **extra):
        spec = {"url": "https://dl.google.com/fixture.zip", "size": len(data),
                "sha256": hashlib.sha256(data).hexdigest(), **extra}
        (root / "platform-tools.lock.json").write_text(json.dumps({"windows": spec}))

    def test_verified_download_and_reuse(self):
        with tempfile.TemporaryDirectory() as td, patch("platform.machine", return_value="AMD64"):
            root = Path(td)
            data = self.archive()
            self.setup_root(root, data)
            path = install(root, "Windows", lambda *a, **k: io.BytesIO(data))
            self.assertEqual(path.read_bytes(), b"binary-adb-fixture\x00\r\n")
            self.assertEqual(install(root, "Windows", lambda *a, **k: self.fail("Downloaded twice")), path)

    def test_tampered_tools_not_reused(self):
        with tempfile.TemporaryDirectory() as td, patch("platform.machine", return_value="AMD64"):
            root = Path(td)
            data = self.archive()
            self.setup_root(root, data)
            path = install(root, "Windows", lambda *a, **k: io.BytesIO(data))
            path.write_bytes(b"modified")
            with self.assertRaisesRegex(RuntimeError, "not verified"):
                install(root, "Windows", lambda *a, **k: io.BytesIO(data))

    def test_wrong_checksum_no_install(self):
        with tempfile.TemporaryDirectory() as td, patch("platform.machine", return_value="AMD64"):
            root = Path(td)
            data = self.archive()
            self.setup_root(root, data, sha256="0" * 64)
            with self.assertRaisesRegex(RuntimeError, "checksum"):
                install(root, "Windows", lambda *a, **k: io.BytesIO(data))
            self.assertFalse((root / "tools/platform-tools").exists())

    def test_oversize_no_install(self):
        with tempfile.TemporaryDirectory() as td, patch("platform.machine", return_value="AMD64"):
            root = Path(td)
            data = self.archive()
            self.setup_root(root, data, size=1)
            with self.assertRaisesRegex(RuntimeError, "larger"):
                install(root, "Windows", lambda *a, **k: io.BytesIO(data))

    def test_traversal_no_extraction(self):
        with tempfile.TemporaryDirectory() as td, patch("platform.machine", return_value="AMD64"):
            root = Path(td)
            data = self.archive("platform-tools/../../escaped.exe")
            self.setup_root(root, data)
            with self.assertRaisesRegex(RuntimeError, "Unsafe"):
                install(root, "Windows", lambda *a, **k: io.BytesIO(data))
            self.assertFalse((root / "escaped.exe").exists())


if __name__ == "__main__":
    unittest.main()
