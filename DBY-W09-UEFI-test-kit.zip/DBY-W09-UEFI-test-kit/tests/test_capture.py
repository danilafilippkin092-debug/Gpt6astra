import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import capture as cap


def sha(data):
    return hashlib.sha256(data).hexdigest()


class FakeADB(cap.ADB):
    def __init__(self, model="DBY-W09", device_lines="unit-serial\tdevice\n", root=True):
        super().__init__("unused")
        self.model, self.lines, self.root_available = model, device_lines, root
        self.calls = []
        self.data = {
            "/dev/block/sda1": b"ANDROID!\x00\xff\xfe\r\n" * 17,
            "/dev/block/sda2": b"\x00\x01\x80\xffdtbo\r\n" * 9,
            "/dev/block/sda3": b"vbmeta\x00\xff\x80" * 11,
        }
        self.names = {"boot": "/dev/block/sda1", "dtbo": "/dev/block/sda2", "vbmeta": "/dev/block/sda3"}
        self.corrupt = False
        self.truncate = False
        self.change_hash = False
        self.hash_calls = {}
        self.interrupt = False

    def run(self, args, **kwargs):
        self.calls.append(args)
        if args == ["devices"]:
            return ("List of devices attached\n" + self.lines).encode()
        raise AssertionError(args)

    def text(self, script, *, root=False):
        self.calls.append((script, root))
        if script == "getprop ro.product.model":
            return self.model
        if script.startswith("getprop "):
            return "example"
        if script == "id -u":
            return "0" if root and self.root_available else "2000"
        if script == cap.INVENTORY:
            return "\n".join("/dev/block/by-name/" + name + "\t" + path for name, path in self.names.items())
        if script.startswith("readlink -f "):
            return self.names[script.split("/")[-1]]
        if script.startswith("blockdev --getsize64 "):
            return str(len(self.data[script.split()[-1]]))
        if script.startswith("sha256sum "):
            path = script.split()[-1]
            self.hash_calls[path] = self.hash_calls.get(path, 0) + 1
            checksum = sha(self.data[path])
            if self.change_hash and self.hash_calls[path] > 1:
                checksum = "0" * 64
            return checksum + "  " + path
        if script.startswith("cat /proc/"):
            return "rootparam=foo androidboot.serialno=unit-serial"
        if script == "test -r /sys/firmware/fdt && echo readable || echo absent":
            return "absent"
        raise AssertionError(script)

    def stream(self, script, destination, limit, **kwargs):
        self.calls.append((script, "stream"))
        if self.interrupt:
            raise KeyboardInterrupt()
        data = self.data[script.split()[-1]]
        if self.corrupt:
            data = b"!" + data[1:]
        if self.truncate:
            data = data[:-1]
        with destination.open("xb") as f:
            f.write(data)
        return len(data)


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.output = Path(self.temp.name) / "capture"

    def tearDown(self):
        self.temp.cleanup()

    def test_binary_capture_hashes_and_verify(self):
        adb = FakeADB()
        result = cap.capture(self.output, adb)
        self.assertTrue(result["complete"])
        self.assertEqual((self.output / "partitions/boot.img").read_bytes(), adb.data["/dev/block/sda1"])
        self.assertEqual(cap.verify(self.output)["status"], "complete")
        self.assertNotIn("unit-serial", (self.output / "manifest.json").read_text())
        self.assertNotIn("unit-serial", (self.output / "cmdline.txt").read_text())
        self.assertTrue(all(p["verified"] for p in result["partitions"]))

    def test_wrong_model_never_attempts_root_or_blocks(self):
        adb = FakeADB(model="MRR-W29")
        with self.assertRaises(cap.CaptureError):
            cap.capture(self.output, adb)
        self.assertFalse(any("id -u" in str(c) or "/dev/block" in str(c) for c in adb.calls))
        self.assertFalse(json.loads((self.output / "manifest.json").read_text())["complete"])

    def test_multiple_unauthorized_offline_devices_fail_before_model(self):
        for lines in ("one\tdevice\ntwo\tdevice\n", "one\tunauthorized\n", "one\toffline\n", ""):
            with self.subTest(lines=lines):
                adb = FakeADB(device_lines=lines)
                with self.assertRaises(cap.CaptureError):
                    adb.select()
                self.assertFalse(any("getprop" in str(c) for c in adb.calls))

    def test_explicit_selection_ignores_other_devices(self):
        adb = FakeADB(device_lines="one\tdevice\ntwo\tunauthorized\n")
        adb.serial = "one"
        adb.select()
        self.assertEqual(adb.serial, "one")

    def test_root_unavailable_does_not_inventory_or_read_partitions(self):
        adb = FakeADB(root=False)
        with self.assertRaises(cap.CaptureError):
            cap.capture(self.output, adb)
        self.assertFalse(any("/dev/block" in str(c) for c in adb.calls))

    def test_hash_mismatch_keeps_only_partial_and_marks_incomplete(self):
        adb = FakeADB()
        adb.corrupt = True
        result = cap.capture(self.output, adb)
        self.assertFalse(result["complete"])
        self.assertFalse((self.output / "partitions/boot.img").exists())
        self.assertTrue((self.output / "partitions/boot.img.partial").exists())
        with self.assertRaises(cap.CaptureError):
            cap.verify(self.output)

    def test_source_hash_change_is_detected(self):
        adb = FakeADB()
        adb.change_hash = True
        result = cap.capture(self.output, adb)
        self.assertFalse(result["complete"])
        self.assertIn("SHA-256", " ".join(result["errors"]))

    def test_truncated_binary_is_not_verified(self):
        adb = FakeADB()
        adb.truncate = True
        result = cap.capture(self.output, adb)
        self.assertFalse(result["complete"])
        self.assertIn("byte count", " ".join(result["errors"]))

    def test_corrupted_local_backup_rejected(self):
        cap.capture(self.output, FakeADB())
        with (self.output / "partitions/boot.img").open("r+b") as f:
            f.write(b"CORRUPT")
        with self.assertRaises(cap.CaptureError):
            cap.verify(self.output)

    def test_existing_directory_never_overwritten(self):
        self.output.mkdir()
        sentinel = self.output / "manifest.json"
        sentinel.write_text("existing")
        with self.assertRaises(FileExistsError):
            cap.capture(self.output, FakeADB())
        self.assertEqual(sentinel.read_text(), "existing")

    def test_missing_critical_group_marks_incomplete(self):
        adb = FakeADB()
        del adb.names["dtbo"]
        result = cap.capture(self.output, adb)
        self.assertFalse(result["complete"])
        self.assertEqual(result["critical_groups"]["dtbo"]["present"], [])
        self.assertIn("dtbo", " ".join(result["errors"]))

    def test_interrupt_leaves_incomplete_manifest(self):
        adb = FakeADB()
        adb.interrupt = True
        with self.assertRaises(KeyboardInterrupt):
            cap.capture(self.output, adb)
        result = json.loads((self.output / "manifest.json").read_text())
        self.assertEqual(result["status"], "interrupted")
        self.assertFalse(result["complete"])

    def test_low_disk_space_prevents_partition_transfer(self):
        adb = FakeADB()
        with patch("capture.shutil.disk_usage", return_value=type("Usage", (), {"free": 1})()):
            with self.assertRaises(cap.CaptureError):
                cap.capture(self.output, adb)
        self.assertFalse(any(c[-1] == "stream" for c in adb.calls if isinstance(c, tuple)))

    def test_partition_size_cap_prevents_transfer(self):
        adb = FakeADB()
        original = adb.text
        def text(script, **kwargs):
            if script.startswith("blockdev --getsize64"):
                return str(cap.MAX_PARTITION + 1)
            return original(script, **kwargs)
        adb.text = text
        with self.assertRaises(cap.CaptureError):
            cap.capture(self.output, adb)
        self.assertFalse(any(c[-1] == "stream" for c in adb.calls if isinstance(c, tuple)))

    def test_verify_detects_path_traversal(self):
        cap.capture(self.output, FakeADB())
        manifest_path = self.output / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["files"][0]["path"] = "../../elsewhere"
        manifest_path.write_text(json.dumps(manifest))
        with self.assertRaises(cap.CaptureError):
            cap.verify(self.output)

    def test_verify_detects_partition_provenance_corruption(self):
        cap.capture(self.output, FakeADB())
        path = self.output / "manifest.json"
        manifest = json.loads(path.read_text())
        next(x for x in manifest["files"] if x.get("kind") == "partition")["source_sha256_before"] = "0" * 64
        path.write_text(json.dumps(manifest))
        with self.assertRaises(cap.CaptureError):
            cap.verify(self.output)

    def test_inventory_deduplicates_aliases_and_excludes_private(self):
        inventory, selected = cap.parse_inventory(
            "/dev/block/by-name/boot\t/dev/block/sda1\n"
            "/dev/block/bootdevice/by-name/boot_a\t/dev/block/sda1\n"
            "/dev/block/by-name/userdata\t/dev/block/sda9\n"
            "/dev/block/by-name/persist\t/dev/block/sda8\n")
        self.assertEqual(len(selected), 1)
        self.assertEqual(len(selected[0]["aliases"]), 2)
        self.assertFalse(next(x for x in inventory if x["name"] == "userdata")["selected"])

    def test_inventory_remote_paths_never_use_host_path(self):
        # A Windows Path would parse /dev/block parents with backslashes.
        # Reject all host-Path construction here: inventory must use PurePosixPath.
        with patch("capture.Path", side_effect=AssertionError("Host Path used for Android path")):
            _, selected = cap.parse_inventory(
                "/dev/block/by-name/boot\t/dev/block/sda1\n"
                "/dev/block/bootdevice/by-name/boot_a\t/dev/block/sda1\n")
        self.assertEqual(selected[0]["name"], "boot_a")
        self.assertEqual(len(selected[0]["aliases"]), 2)

    def test_same_partition_name_different_canonical_is_rejected(self):
        inventory = (
            "/dev/block/by-name/boot\t/dev/block/sda1\n"
            "/dev/block/bootdevice/by-name/boot\t/dev/block/sdb1\n")
        with self.assertRaisesRegex(cap.CaptureError, "different block devices"):
            cap.parse_inventory(inventory)

    def test_ambiguous_name_stops_capture_before_large_reads(self):
        adb = FakeADB()
        original = adb.text
        def text(script, **kwargs):
            if script == cap.INVENTORY:
                return (
                    "/dev/block/by-name/boot\t/dev/block/sda1\n"
                    "/dev/block/bootdevice/by-name/boot\t/dev/block/sdb1\n")
            return original(script, **kwargs)
        adb.text = text
        with self.assertRaisesRegex(cap.CaptureError, "different block devices"):
            cap.capture(self.output, adb)
        self.assertFalse(any("blockdev" in str(c) or "sha256sum" in str(c) or c[-1] == "stream"
                             for c in adb.calls if isinstance(c, tuple)))

    def test_verify_remote_aliases_never_use_host_path(self):
        cap.capture(self.output, FakeADB())
        real_path = cap.Path
        def host_path(value):
            if isinstance(value, str) and value.startswith("/dev/block/"):
                raise AssertionError("Host Path used for Android path")
            return real_path(value)
        with patch("capture.Path", side_effect=host_path):
            self.assertTrue(cap.verify(self.output)["complete"])

    def test_capture_verified_names_never_use_host_path(self):
        real_path = cap.Path
        def host_path(value):
            if isinstance(value, str) and value.startswith("/dev/block/"):
                raise AssertionError("Host Path used for Android path")
            return real_path(value)
        with patch("capture.Path", side_effect=host_path):
            self.assertTrue(cap.capture(self.output, FakeADB())["complete"])

    def test_unsafe_inventory_rejected(self):
        for text in ("/dev/block/by-name/boot\t/dev/block/../etc/shadow", "bad", "/dev/block/by-name/boot;rm -r\t/dev/block/sda1"):
            with self.subTest(text=text), self.assertRaises(cap.CaptureError):
                cap.parse_inventory(text)


class PublishTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / "source.partial"
        self.target = Path(self.temp.name) / "target.img"
        self.source.write_bytes(bytes(range(256)))

    def tearDown(self):
        self.temp.cleanup()

    def test_publish_preserves_bytes_and_removes_partial(self):
        cap.publish_file(self.source, self.target)
        self.assertEqual(self.target.read_bytes(), bytes(range(256)))
        self.assertFalse(self.source.exists())

    def test_publish_never_overwrites_existing_target(self):
        self.target.write_bytes(b"original")
        with self.assertRaises(FileExistsError):
            cap.publish_file(self.source, self.target)
        self.assertEqual(self.target.read_bytes(), b"original")
        self.assertEqual(self.source.read_bytes(), bytes(range(256)))

    def test_publish_interruption_removes_only_new_target(self):
        with patch("capture.shutil.copyfileobj", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                cap.publish_file(self.source, self.target)
        self.assertTrue(self.source.exists())
        self.assertFalse(self.target.exists())

    def test_publish_does_not_follow_existing_target_symlink(self):
        existing = Path(self.temp.name) / "original.img"
        existing.write_bytes(b"original")
        self.target.symlink_to(existing)
        with self.assertRaises(FileExistsError):
            cap.publish_file(self.source, self.target)
        self.assertEqual(existing.read_bytes(), b"original")
        self.assertTrue(self.source.exists())


class StreamTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.destination = Path(self.temp.name) / "test.partial"
        self.adb = cap.ADB(sys.executable, "test")

    def tearDown(self):
        self.temp.cleanup()

    def run_python(self, code, limit=1000, timeout=5):
        self.adb.command = lambda script, root: ["-c", code]
        return self.adb.stream("unused", self.destination, limit, timeout=timeout)

    def test_stream_preserves_every_byte(self):
        self.assertEqual(self.run_python("import sys; sys.stdout.buffer.write(bytes(range(256)))"), 256)
        self.assertEqual(self.destination.read_bytes(), bytes(range(256)))

    def test_stream_caps_excess_output(self):
        with self.assertRaises(cap.CaptureError):
            self.run_python("import sys; sys.stdout.buffer.write(b'x'*10000)", limit=100)
        self.assertLessEqual(self.destination.stat().st_size, 100)

    def test_stream_nonzero_exit(self):
        with self.assertRaises(cap.CaptureError):
            self.run_python("import sys; sys.stdout.buffer.write(b'failed'); sys.exit(1)")

    def test_stream_kills_hung_host_adb(self):
        with self.assertRaises(cap.CaptureError):
            self.run_python("import time; time.sleep(30)", timeout=0.1)

    def test_stream_does_not_overwrite_file(self):
        self.destination.write_bytes(b"previous")
        with self.assertRaises(FileExistsError):
            self.run_python("print('new')")
        self.assertEqual(self.destination.read_bytes(), b"previous")


if __name__ == "__main__":
    unittest.main()
