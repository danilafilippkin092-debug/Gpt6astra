#!/system/bin/sh
# Called by Magisk late_start; does nothing unless this test was armed.
BASE=/data/adb/dby-uefi-report
REPORTS=/data/media/0/reports_uefi
[ -f "$BASE/pending" ] || exit 0
# Wait for Android and credential-encrypted user storage after unlock.
if [ "${1:-}" != --now ]; then
 N=0
 while [ "$(getprop sys.boot_completed)" != 1 ] || [ ! -f /data/media/0/DBY-UEFI-REPORT-03/prepare-state.json ]; do
  N=$((N+1)); [ "$N" -lt 300 ] || exit 0
  sleep 2
 done
fi
umask 077
STAMP=$(date +%Y%m%d-%H%M%S)
DEST="$REPORTS/android-after-uefi-$STAMP-$$"
mkdir -p "$DEST" || exit 1
printf '%s\n' 'Android-side collection after restoration. These are NOT live UEFI logs.' > "$DEST/README.txt"
getprop ro.boot.bootreason > "$DEST/android-boot-reason.txt"
uname -r > "$DEST/android-kernel.txt"
getprop ro.product.model > "$DEST/model.txt"
# dmesg belongs to this Android boot; pstore may be unrelated or empty.
dmesg 2>/dev/null | tail -c 1048576 > "$DEST/android-dmesg.txt"
mkdir -p "$DEST/pstore"
N=0
for P in /sys/fs/pstore/*; do
 [ -f "$P" ] || continue
 [ ! -L "$P" ] || continue
 N=$((N+1)); [ "$N" -le 8 ] || break
 dd if="$P" of="$DEST/pstore/$(basename "$P")" bs=65536 count=4 2>/dev/null
done
for NAME in prepare-state.json start-state.json runtime-report.json; do
 P="/data/media/0/DBY-UEFI-REPORT-03/$NAME"
 [ -f "$P" ] && [ ! -L "$P" ] && dd if="$P" of="$DEST/$NAME" bs=65536 count=1 2>/dev/null
done
BOOT=''
for P in /dev/block/by-name/boot /dev/block/bootdevice/by-name/boot; do
 [ -b "$P" ] && BOOT=$P && break
done
[ -z "$BOOT" ] || sha256sum "$BOOT" > "$DEST/current-boot.sha256"
chmod 755 "$REPORTS" "$DEST" "$DEST/pstore"
find "$DEST" -type f -exec chmod 644 {} \;
if tar -czf "$DEST.tar.gz" -C "$REPORTS" "$(basename "$DEST")"; then
 chmod 644 "$DEST.tar.gz"
 rm -f "$BASE/pending"
fi
# Raw partition images and encrypted userdata are never copied.
