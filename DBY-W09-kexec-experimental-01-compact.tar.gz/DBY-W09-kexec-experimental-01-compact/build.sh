#!/usr/bin/env bash
set -euo pipefail
export KBUILD_BUILD_USER=codex KBUILD_BUILD_HOST=experiment KBUILD_BUILD_VERSION=1
export KBUILD_BUILD_TIMESTAMP="1970-01-01 00:00:00 UTC"
kit_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
source_dir="$kit_dir/source/kernel"
if [[ ! -f "$source_dir/Makefile" ]]; then python3 "$kit_dir/fetch-source.py"; fi
output_dir="${OUT_DIR:-$kit_dir/out}"
mkdir -p -- "$output_dir"
output_dir=$(cd -- "$output_dir" && pwd)
if [[ "$output_dir" == "$source_dir" ]]; then echo 'Use a separate OUT_DIR' >&2; exit 2; fi
cp -- "$kit_dir/config/experimental.config" "$output_dir/.config"
build_args=(-C "$source_dir" O="$output_dir" ARCH=arm64
  CC="${CC:-clang}" HOSTCC="${HOSTCC:-gcc -fcommon}"
  LD="${LD:-ld.lld}" CROSS_COMPILE="${CROSS_COMPILE:-aarch64-linux-gnu-}"
  KCFLAGS="-ffreestanding -Wno-error=strict-prototypes -Wno-error=unused-but-set-variable")
make "${build_args[@]}" olddefconfig
for flag in KEXEC KEXEC_CORE; do
  grep -qx "CONFIG_${flag}=y" "$output_dir/.config" || { echo "Missing CONFIG_${flag}" >&2; exit 3; }
done
make "${build_args[@]}" -j"${JOBS:-2}" Image.gz 2>&1 | tee "$output_dir/build.log"
test -s "$output_dir/arch/arm64/boot/Image.gz"
echo "Kernel compiled: $output_dir/arch/arm64/boot/Image.gz"
echo 'Not an Android boot image. No hardware boot or UEFI handoff validation.'
