#include <linux/blkdev.h>
#include <linux/blk-mq.h>
const unsigned long probe_q_mq_ops = __builtin_offsetof(struct request_queue, mq_ops);
const unsigned long probe_q_tag_set = __builtin_offsetof(struct request_queue, tag_set);
const unsigned long probe_q_queue_tags = __builtin_offsetof(struct request_queue, queue_tags);
const unsigned long probe_q_lld_func = __builtin_offsetof(struct request_queue, lld_func);
const unsigned long probe_tagset_lld_func = __builtin_offsetof(struct blk_mq_tag_set, lld_func);
const unsigned long probe_queue_tag_lld_func = __builtin_offsetof(struct blk_queue_tag, lld_func);
