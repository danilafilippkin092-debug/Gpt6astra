#!/usr/bin/env python3
"""Fetch the public Huawei source archive, verify it, and apply the kit patch."""
from pathlib import Path, PurePosixPath
import argparse,hashlib,json,urllib.request,gzip,tarfile,shutil,tempfile,subprocess
kit=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
meta=json.loads((kit/'SOURCE.json').read_text())
cache=kit/'.source-cache';archive=args.archive
if archive is None:
 cache.mkdir(exist_ok=True);archive=cache/'DBY-W09-HarmonyOS2-official.tar.gz'
 if not archive.exists():
  partial=archive.with_suffix('.gz.partial')
  with urllib.request.urlopen(meta['download_url'],timeout=90)as response,partial.open('wb')as target:
   shutil.copyfileobj(response,target,1024*1024)
  partial.rename(archive)
with archive.open('rb')as handle:digest=hashlib.file_digest(handle,'sha256').hexdigest() if hasattr(hashlib,'file_digest') else None
if digest is None:
 h=hashlib.sha256()
 with archive.open('rb')as handle:
  while True:
   block=handle.read(1024*1024)
   if not block:break
   h.update(block)
 digest=h.hexdigest()
if digest!=meta['original_archive_sha256']:raise SystemExit('Huawei source archive SHA256 mismatch; nothing extracted')
if args.verify_only:
 print('Official Huawei archive SHA256 verified');raise SystemExit(0)
source_parent=kit/'source';source_parent.mkdir(exist_ok=True);destination=source_parent/'kernel'
if destination.exists():raise SystemExit('source/kernel already exists; leaving it unchanged')
staging=Path(tempfile.mkdtemp(prefix='.kernel-staging-',dir=source_parent));count=0
try:
 with gzip.open(archive,'rb')as gz:
  with tarfile.open(fileobj=gz,mode='r|')as tar:
   for member in tar:
    path=PurePosixPath(member.name)
    if path.is_absolute()or '..'in path.parts:raise RuntimeError('Unsafe archive path')
    prefix='Code_Opensource/kernel/'
    if not member.name.startswith(prefix):continue
    relative=member.name[len(prefix):]
    if not relative:continue
    relpath=PurePosixPath(relative)
    if relpath.is_absolute()or '..'in relpath.parts:raise RuntimeError('Unsafe kernel-relative path')
    target=staging/relpath.as_posix()
    if member.isdir():target.mkdir(parents=True,exist_ok=True)
    elif member.isfile():
     target.parent.mkdir(parents=True,exist_ok=True)
     with tar.extractfile(member)as src,target.open('wb')as dst:shutil.copyfileobj(src,dst)
     target.chmod(0o755 if member.mode&0o111 else 0o644);count+=1
    else:raise RuntimeError('Unexpected link or special member in kernel source')
  while gz.read(1024*1024):pass
 if not(staging/'Makefile').is_file():raise RuntimeError('Kernel source missing')
 subprocess.run(['patch','--batch','--forward','-p1','-i',str(kit/'SOURCE-CHANGES.patch')],cwd=staging,check=True)
 staging.rename(destination);print('Verified and patched kernel source files:',count)
finally:
 if staging.exists():shutil.rmtree(staging)
